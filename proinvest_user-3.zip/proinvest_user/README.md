# PRO INVEST — User App (com.tbb.user)

Investor-facing Android app for PRO INVEST.

## Features
- Register / Login
- Investment Plans & My Investments
- Deposit & Withdraw (bKash / Nagad style)
- Daily Missions, Check-in, Spin Wheel
- Achievements, Challenges, Loyalty Points, Referral
- Transactions, Notifications, Profile, Support
- Risk Disclosure, Terms, Privacy

## Demo Login
- Email: `user@proinvest.com`
- Password: `pass123`

Admin accounts are **rejected** in this app. Use the separate **PRO INVEST Admin** app.

## Package
- `applicationId`: `com.tbb.user`
- Firebase: `ff-win-oo` (google-services.json included)

## Run
1. Open in Android Studio
2. Sync Gradle
3. Run on device/emulator (minSdk 24)
