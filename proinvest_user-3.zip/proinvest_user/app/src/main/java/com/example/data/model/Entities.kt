package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fullName: String,
    val email: String,
    val phone: String,
    val passwordHash: String,
    val referralCode: String,
    val referredBy: String? = null,
    val level: Int = 1,
    val xp: Int = 150,
    val availableBalance: Double = 12500.0, // Initial legitimate test balance
    val activeInvestments: Double = 0.0,
    val pendingWithdrawal: Double = 0.0,
    val promotionalCredits: Double = 500.0,
    val loyaltyPoints: Int = 240,
    val isVerified: Boolean = false,
    val isAdmin: Boolean = false,
    val streakDays: Int = 3,
    val lastCheckInDate: String = "",
    val lastSpinDate: String = "",
    val spinsAvailableToday: Int = 1,
    val completedMissionsCount: Int = 4,
    val mysteryBoxOpened: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "investment_plans")
data class InvestmentPlanEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String, // STARTER, GROWTH, PREMIUM
    val minAmount: Double,
    val maxAmount: Double,
    val durationDays: Int,
    val estAnnualYieldMin: Double, // e.g. 8.5%
    val estAnnualYieldMax: Double, // e.g. 12.0%
    val feePercentage: Double,
    val riskLevel: String, // Low, Moderate, Dynamic
    val description: String,
    val terms: String,
    val isActive: Boolean = true
)

@Entity(tableName = "investments")
data class InvestmentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val planId: Long,
    val planName: String,
    val investedAmount: Double,
    val durationDays: Int,
    val dailyYieldRate: Double, // Daily pro-rata yield calculation
    val startDate: Long,
    val maturityDate: Long,
    val accruedProfit: Double = 0.0,
    val status: String = "ACTIVE" // ACTIVE, COMPLETED, WITHDRAWN
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val type: String, // DEPOSIT, WITHDRAWAL, INVESTMENT, PROFIT, REFERRAL_REWARD, SPIN_REWARD, MISSION_REWARD, LOYALTY_REDEEM
    val amount: Double,
    val fee: Double = 0.0,
    val status: String, // PENDING, APPROVED, COMPLETED, REJECTED
    val paymentMethod: String, // bKash, Nagad, Bank Transfer, Available Balance, Loyalty Store
    val referenceId: String,
    val description: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_missions")
data class DailyMissionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val missionCode: String,
    val title: String,
    val description: String,
    val timeEstimate: String,
    val rewardType: String, // XP, POINTS, PROMO
    val rewardAmount: Int,
    val missionType: String, // CHECKIN, QUIZ, TIP, SECURITY, ANNOUNCEMENT, PROFILE
    val isCompleted: Boolean = false,
    val isClaimed: Boolean = false,
    val details: String = ""
)

@Entity(tableName = "weekly_challenges")
data class WeeklyChallengeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String,
    val targetCount: Int,
    val currentCount: Int,
    val rewardXp: Int,
    val rewardPoints: Int,
    val isCompleted: Boolean = false,
    val isClaimed: Boolean = false,
    val endDateStr: String
)

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val code: String,
    val title: String,
    val description: String,
    val iconName: String,
    val xpReward: Int,
    val isUnlocked: Boolean = false,
    val unlockedAt: Long? = null
)

@Entity(tableName = "spin_history")
data class SpinHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val rewardLabel: String,
    val rewardType: String,
    val rewardAmount: Double,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val title: String,
    val message: String,
    val category: String, // FINANCIAL, MISSION, SPIN, REFERRAL, SECURITY, ANNOUNCEMENT
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

@Entity(tableName = "support_tickets")
data class SupportTicketEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val userEmail: String,
    val subject: String,
    val category: String, // DEPOSIT, WITHDRAWAL, INVESTMENT, ACCOUNT, GENERAL
    val message: String,
    val adminResponse: String? = null,
    val status: String = "OPEN", // OPEN, ANSWERED, RESOLVED
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "promotional_banners")
data class BannerEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val subtitle: String,
    val tag: String,
    val actionRoute: String,
    val isActive: Boolean = true
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val actor: String,
    val action: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)
