package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NotificationEntity
import com.example.data.model.TransactionEntity
import com.example.ui.components.CategoryFilterChip
import com.example.ui.components.ProHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.TransactionRow
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProInvestViewModel
import com.example.ui.viewmodel.Screen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReferralScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val context = LocalContext.current
    val referralCode = currentUser?.referralCode ?: "PRO-7892"
    val referralLink = "https://proinvest.app/ref/$referralCode"

    Scaffold(
        topBar = {
            ProHeader(
                title = "Referral Program",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("referral_screen_scroll"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Referral Hero Banner
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(NavyDark, Color(0xFF1E293B))))
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(ElectricBlue, Color(0xFF8B5CF6)))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.GroupAdd, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            "Invite Friends, Earn Rewards",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Get 500 Loyalty Points + 250 XP for every friend who registers and verifies their KYC account.",
                            fontSize = 12.sp,
                            color = SlateTextMuted,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }

            // Referral Code Box
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Your Exclusive Referral Code", fontSize = 12.sp, color = SlateTextSecondary)
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                referralCode,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = ElectricBlue
                            )

                            Button(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Referral Code", referralCode))
                                    viewModel.showMessage("Referral code copied to clipboard!")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Copy", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Share Link Button
                        OutlinedButton(
                            onClick = {
                                val sendIntent: Intent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, "Join PRO INVEST using my referral code $referralCode: $referralLink")
                                    type = "text/plain"
                                }
                                val shareIntent = Intent.createChooser(sendIntent, "Share Referral Link")
                                context.startActivity(shareIntent)
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share Invitation Link", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Referral Stats
            item {
                Text("Referral Performance", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(label = "Total Invited", value = "6 Users", modifier = Modifier.weight(1f))
                    StatCard(label = "Verified KYC", value = "4 Users", modifier = Modifier.weight(1f))
                    StatCard(label = "Total Earned", value = "2,000 Pts", modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, fontSize = 10.sp, color = SlateTextSecondary)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun LoyaltyPointsScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()

    Scaffold(
        topBar = {
            ProHeader(
                title = "Loyalty Rewards Store",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("loyalty_screen_scroll"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Points Balance Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Brush.horizontalGradient(listOf(NavyDark, Color(0xFF831843))))
                            .padding(18.dp)
                    ) {
                        Text("Available Loyalty Points", fontSize = 12.sp, color = SlateTextMuted)
                        Text(
                            "${currentUser?.loyaltyPoints ?: 0} Pts",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "Points can be redeemed for profile customizations, fee discounts, extra daily spins, and platform perks.",
                            fontSize = 11.sp,
                            color = SlateTextMuted
                        )
                    }
                }
            }

            item {
                Text("Available Redemptions", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }

            // Perks
            item {
                LoyaltyPerkItem(
                    title = "৳250 Promotional Investment Credit",
                    description = "Bonus credit to deploy into any starter or growth fund.",
                    pointsCost = 500,
                    onRedeem = { viewModel.redeemLoyalty("৳250 Promotional Credit", 500, "PROMO") }
                )
            }
            item {
                LoyaltyPerkItem(
                    title = "Extra Daily Spin Token",
                    description = "Adds 1 extra free spin to your daily fortune wheel.",
                    pointsCost = 150,
                    onRedeem = { viewModel.redeemLoyalty("Extra Daily Spin", 150, "SPIN") }
                )
            }
            item {
                LoyaltyPerkItem(
                    title = "VIP Gold Avatar Frame",
                    description = "Special badge border displayed across your profile.",
                    pointsCost = 300,
                    onRedeem = { viewModel.redeemLoyalty("VIP Gold Avatar Frame", 300, "FRAME") }
                )
            }
            item {
                LoyaltyPerkItem(
                    title = "50% Fee Waiver Voucher",
                    description = "Waiver on platform processing fees for your next withdrawal.",
                    pointsCost = 400,
                    onRedeem = { viewModel.redeemLoyalty("50% Fee Waiver", 400, "FEE") }
                )
            }
        }
    }
}

@Composable
fun LoyaltyPerkItem(
    title: String,
    description: String,
    pointsCost: Int,
    onRedeem: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(2.dp))
                Text(description, fontSize = 11.sp, color = SlateTextSecondary)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Button(
                onClick = onRedeem,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDB2777)),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text("$pointsCost Pts", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun TransactionsScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val transactions by viewModel.userTransactions.collectAsState()
    var filterType by remember { mutableStateOf("ALL") }
    var searchQuery by remember { mutableStateOf("") }

    val filtered = remember(transactions, filterType, searchQuery) {
        transactions.filter { tx ->
            val matchType = if (filterType == "ALL") true else tx.type == filterType
            val matchSearch = searchQuery.isBlank() ||
                    tx.description.contains(searchQuery, ignoreCase = true) ||
                    tx.referenceId.contains(searchQuery, ignoreCase = true) ||
                    tx.paymentMethod.contains(searchQuery, ignoreCase = true)
            matchType && matchSearch
        }
    }

    Scaffold(
        topBar = {
            ProHeader(
                title = "Account Ledger & History",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("transactions_screen_scroll"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Search Input
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by reference, method, or note") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SlateTextMuted) },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Filters
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CategoryFilterChip("All", filterType == "ALL") { filterType = "ALL" }
                    CategoryFilterChip("Deposits", filterType == "DEPOSIT") { filterType = "DEPOSIT" }
                    CategoryFilterChip("Withdrawals", filterType == "WITHDRAWAL") { filterType = "WITHDRAWAL" }
                    CategoryFilterChip("Investments", filterType == "INVESTMENT") { filterType = "INVESTMENT" }
                }
            }

            if (filtered.isEmpty()) {
                item {
                    Text(
                        "No matching records found in ledger.",
                        fontSize = 13.sp,
                        color = SlateTextMuted,
                        modifier = Modifier.padding(vertical = 20.dp)
                    )
                }
            } else {
                items(filtered) { tx ->
                    TransactionRow(tx = tx)
                }
            }
        }
    }
}

@Composable
fun NotificationsScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val notifications by viewModel.notifications.collectAsState()

    Scaffold(
        topBar = {
            ProHeader(
                title = "Notifications",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("notifications_scroll"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${notifications.size} Updates",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = { viewModel.markAllNotificationsRead() }) {
                        Text("Mark all as read", fontSize = 12.sp, color = ElectricBlue)
                    }
                }
            }

            if (notifications.isEmpty()) {
                item {
                    Text("No notifications yet.", fontSize = 13.sp, color = SlateTextMuted)
                }
            } else {
                items(notifications) { n ->
                    NotificationCard(n = n)
                }
            }
        }
    }
}

@Composable
fun NotificationCard(n: NotificationEntity) {
    val dateFormat = SimpleDateFormat("MMM dd, hh:mm a", Locale.US)
    val timeStr = dateFormat.format(Date(n.timestamp))

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (n.isRead) MaterialTheme.colorScheme.surface else ElectricBlueSoft.copy(alpha = 0.2f),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (n.isRead) MaterialTheme.colorScheme.outline.copy(alpha = 0.3f) else ElectricBlue.copy(alpha = 0.5f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(
                        when (n.category) {
                            "FINANCIAL" -> EmeraldSuccessLight
                            "SPIN" -> AmberGoldLight
                            "SECURITY" -> RoseErrorLight
                            else -> ElectricBlueSoft
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    when (n.category) {
                        "FINANCIAL" -> Icons.Default.AccountBalanceWallet
                        "SPIN" -> Icons.Default.Casino
                        "SECURITY" -> Icons.Default.Security
                        else -> Icons.Default.Notifications
                    },
                    contentDescription = null,
                    tint = when (n.category) {
                        "FINANCIAL" -> EmeraldSuccess
                        "SPIN" -> AmberGoldDark
                        "SECURITY" -> RoseError
                        else -> ElectricBlue
                    },
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(n.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(2.dp))
                Text(n.message, fontSize = 11.sp, color = SlateTextSecondary, lineHeight = 15.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(timeStr, fontSize = 10.sp, color = SlateTextMuted)
            }
        }
    }
}

@Composable
fun ProfileScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()

    Scaffold(
        topBar = {
            ProHeader(
                title = "Profile & Settings",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("profile_screen_scroll"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(NavyDark, NavyCard)))
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(ElectricBlue, AmberGold))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                (currentUser?.fullName?.take(1) ?: "U").uppercase(),
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            currentUser?.fullName ?: "Investor",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            currentUser?.email ?: "user@proinvest.com",
                            fontSize = 12.sp,
                            color = SlateTextMuted
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StatusPill(status = if (currentUser?.isVerified == true) "VERIFIED KYC" else "UNVERIFIED")
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = NavySurface
                            ) {
                                Text(
                                    "Ref: ${currentUser?.referralCode ?: "PRO-0000"}",
                                    fontSize = 11.sp,
                                    color = AmberGoldLight,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Menu Items
            item {
                ProfileMenuItem(
                    title = "Help & Customer Support",
                    subtitle = "FAQs and 24/7 ticket support",
                    icon = Icons.Default.HelpOutline,
                    onClick = { viewModel.navigateTo(Screen.SUPPORT) }
                )
                Spacer(modifier = Modifier.height(8.dp))
                ProfileMenuItem(
                    title = "Investment Risk Disclosure",
                    subtitle = "Legal risk policy and yield transparency",
                    icon = Icons.Default.Gavel,
                    onClick = { viewModel.navigateTo(Screen.RISK_DISCLOSURE) }
                )
                Spacer(modifier = Modifier.height(8.dp))
                ProfileMenuItem(
                    title = "Terms & Conditions",
                    subtitle = "Platform user agreement",
                    icon = Icons.Default.Description,
                    onClick = { viewModel.navigateTo(Screen.TERMS) }
                )
                Spacer(modifier = Modifier.height(8.dp))
                ProfileMenuItem(
                    title = "Privacy Policy",
                    subtitle = "Data security & protection standards",
                    icon = Icons.Default.Security,
                    onClick = { viewModel.navigateTo(Screen.PRIVACY) }
                )
            }

            // Logout Button
            item {
                OutlinedButton(
                    onClick = { viewModel.logout() },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = RoseError),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RoseError.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("profile_logout_button")
                ) {
                    Icon(Icons.Default.Logout, contentDescription = null, tint = RoseError)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Sign Out", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ProfileMenuItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(icon, contentDescription = title, tint = ElectricBlue, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(subtitle, fontSize = 11.sp, color = SlateTextSecondary)
                }
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = SlateTextMuted)
        }
    }
}
