package com.example.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProInvestViewModel
import com.example.ui.viewmodel.Screen

data class NavItem(
    val screen: Screen,
    val title: String,
    val icon: ImageVector
)

@Composable
fun ProInvestApp(viewModel: ProInvestViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val uiMessage by viewModel.uiMessage.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiMessage) {
        uiMessage?.let { msg ->
            snackbarHostState.showSnackbar(
                message = msg.message,
                duration = SnackbarDuration.Short
            )
            viewModel.clearMessage()
        }
    }

    BackHandler(enabled = currentScreen != Screen.HOME && currentScreen != Screen.AUTH) {
        viewModel.navigateBack()
    }

    val bottomNavItems = remember {
        listOf(
            NavItem(Screen.HOME, "Home", Icons.Default.Home),
            NavItem(Screen.PLANS, "Plans", Icons.Default.TrendingUp),
            NavItem(Screen.MISSIONS, "Missions", Icons.Default.AssignmentTurnedIn),
            NavItem(Screen.SPIN_WHEEL, "Spin", Icons.Default.Casino),
            NavItem(Screen.PROFILE, "Profile", Icons.Default.Person)
        )
    }

    val showBottomBar = currentScreen in listOf(
        Screen.HOME,
        Screen.PLANS,
        Screen.MISSIONS,
        Screen.SPIN_WHEEL,
        Screen.PROFILE
    )

    Scaffold(
        snackbarHost = {
            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier.padding(bottom = if (showBottomBar) 60.dp else 16.dp)
            ) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = NavyDark,
                    contentColor = androidx.compose.ui.graphics.Color.White,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                )
            }
        },
        bottomBar = {
            AnimatedVisibility(
                visible = showBottomBar,
                enter = slideInVertically(tween(280)) { it } + fadeIn(tween(280)),
                exit = slideOutVertically(tween(220)) { it } + fadeOut(tween(220))
            ) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    windowInsets = WindowInsets.navigationBars,
                    modifier = Modifier.testTag("pro_invest_bottom_bar")
                ) {
                    bottomNavItems.forEach { item ->
                        val isSelected = currentScreen == item.screen
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { viewModel.navigateTo(item.screen) },
                            icon = {
                                Icon(
                                    item.icon,
                                    contentDescription = item.title,
                                    tint = if (isSelected) ElectricBlue else theSlate()
                                )
                            },
                            label = {
                                Text(
                                    item.title,
                                    fontSize = 11.sp,
                                    color = if (isSelected) ElectricBlue else theSlate()
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = ElectricBlueSoft
                            )
                        )
                    }
                }
            }
        },
        contentWindowInsets = WindowInsets.safeDrawing,
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    val forward = targetState.ordinal >= initialState.ordinal
                    if (forward) {
                        (slideInHorizontally(tween(320)) { it / 5 } + fadeIn(tween(280))) togetherWith
                                (slideOutHorizontally(tween(280)) { -it / 8 } + fadeOut(tween(220)))
                    } else {
                        (slideInHorizontally(tween(320)) { -it / 5 } + fadeIn(tween(280))) togetherWith
                                (slideOutHorizontally(tween(280)) { it / 8 } + fadeOut(tween(220)))
                    }.using(SizeTransform(clip = false))
                },
                label = "screenTransition"
            ) { screen ->
                when (screen) {
                    Screen.AUTH -> AuthScreen(viewModel = viewModel)
                    Screen.HOME -> HomeScreen(viewModel = viewModel)
                    Screen.PLANS -> InvestmentPlansScreen(viewModel = viewModel)
                    Screen.MY_INVESTMENTS -> MyInvestmentsScreen(viewModel = viewModel)
                    Screen.DEPOSIT -> DepositScreen(viewModel = viewModel)
                    Screen.WITHDRAW -> WithdrawScreen(viewModel = viewModel)
                    Screen.MISSIONS -> DailyMissionScreen(viewModel = viewModel)
                    Screen.CHECK_IN -> DailyCheckInScreen(viewModel = viewModel)
                    Screen.SPIN_WHEEL -> SpinRewardsScreen(viewModel = viewModel)
                    Screen.REFERRAL -> ReferralScreen(viewModel = viewModel)
                    Screen.ACHIEVEMENTS, Screen.CHALLENGES -> AchievementsScreen(viewModel = viewModel)
                    Screen.LOYALTY -> LoyaltyPointsScreen(viewModel = viewModel)
                    Screen.TRANSACTIONS -> TransactionsScreen(viewModel = viewModel)
                    Screen.NOTIFICATIONS -> NotificationsScreen(viewModel = viewModel)
                    Screen.PROFILE -> ProfileScreen(viewModel = viewModel)
                    Screen.SUPPORT -> SupportScreen(viewModel = viewModel)
                    Screen.RISK_DISCLOSURE -> RiskDisclosureScreen(viewModel = viewModel)
                    Screen.TERMS -> TermsScreen(viewModel = viewModel)
                    Screen.PRIVACY -> PrivacyScreen(viewModel = viewModel)
                    Screen.ADMIN_PANEL -> HomeScreen(viewModel = viewModel)
                }
            }

            // Global overlay loader
            AnimatedVisibility(
                visible = isLoading,
                enter = fadeIn(tween(200)),
                exit = fadeOut(tween(200))
            ) {
                com.example.ui.components.FullScreenLoader("Please wait…")
            }
        }
    }
}

@Composable
private fun theSlate() = SlateTextSecondary
