package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ProHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.TransactionRow
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProInvestViewModel
import java.util.Locale

@Composable
fun DepositScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val transactions by viewModel.userTransactions.collectAsState()
    val depositHistory = remember(transactions) { transactions.filter { it.type == "DEPOSIT" } }

    val context = LocalContext.current
    var selectedMethod by remember { mutableStateOf("bKash") }
    var amountText by remember { mutableStateOf("") }
    var senderNumber by remember { mutableStateOf(currentUser?.phone ?: "") }
    var txId by remember { mutableStateOf("") }

    val agentNumber = when (selectedMethod) {
        "bKash" -> "01712-998877"
        "Nagad" -> "01988-334455"
        else -> "City Bank A/C: 11029384729"
    }

    Scaffold(
        topBar = {
            ProHeader(
                title = "Deposit Funds",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("deposit_screen_scroll"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Balance Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Brush.horizontalGradient(listOf(NavyDark, NavyCard)))
                            .padding(16.dp)
                    ) {
                        Text("Current Withdrawable Balance", fontSize = 12.sp, color = SlateTextMuted)
                        Text(
                            "৳" + String.format(Locale.US, "%,.2f", currentUser?.availableBalance ?: 0.0),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            // Payment Methods
            item {
                Text(
                    "Select Payment Method",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MethodSelectCard(
                        name = "bKash",
                        icon = Icons.Default.PhoneAndroid,
                        color = Color(0xFFE2136E),
                        isSelected = selectedMethod == "bKash",
                        onClick = { selectedMethod = "bKash" },
                        modifier = Modifier.weight(1f)
                    )
                    MethodSelectCard(
                        name = "Nagad",
                        icon = Icons.Default.SendToMobile,
                        color = Color(0xFFF97316),
                        isSelected = selectedMethod == "Nagad",
                        onClick = { selectedMethod = "Nagad" },
                        modifier = Modifier.weight(1f)
                    )
                    MethodSelectCard(
                        name = "Bank",
                        icon = Icons.Default.AccountBalance,
                        color = ElectricBlue,
                        isSelected = selectedMethod == "Bank",
                        onClick = { selectedMethod = "Bank" },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Agent Payment Details & Copy
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            "Official Deposit Account Details",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Transfer funds to this merchant / agent number, then submit your transaction reference below:",
                            fontSize = 11.sp,
                            color = SlateTextSecondary
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                agentNumber,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Agent Number", agentNumber))
                                    viewModel.showMessage("Copied $agentNumber to clipboard")
                                }
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = ElectricBlue, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }

            // Deposit Form
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "Submit Deposit Reference",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = it },
                            label = { Text("Deposit Amount (৳)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("deposit_amount_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = senderNumber,
                            onValueChange = { senderNumber = it },
                            label = { Text("Sender Mobile / Account Number") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("deposit_sender_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = txId,
                            onValueChange = { txId = it },
                            label = { Text("Transaction ID (TrxID / Reference)") },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("deposit_txid_input")
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                val amt = amountText.toDoubleOrNull() ?: 0.0
                                if (amt < 100.0) {
                                    viewModel.showMessage("Minimum deposit is ৳100", isError = true)
                                } else if (txId.isBlank()) {
                                    viewModel.showMessage("Please enter the Transaction ID", isError = true)
                                } else {
                                    viewModel.requestDeposit(amt, selectedMethod, senderNumber, txId)
                                    amountText = ""
                                    txId = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("submit_deposit_button")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Submit Deposit Request", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Deposit History
            item {
                Text(
                    "Deposit History",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            if (depositHistory.isEmpty()) {
                item {
                    Text(
                        "No deposit requests made yet.",
                        fontSize = 12.sp,
                        color = SlateTextMuted
                    )
                }
            } else {
                items(depositHistory) { tx ->
                    TransactionRow(tx = tx)
                }
            }
        }
    }
}

@Composable
fun WithdrawScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val transactions by viewModel.userTransactions.collectAsState()
    val withdrawHistory = remember(transactions) { transactions.filter { it.type == "WITHDRAWAL" } }

    var selectedMethod by remember { mutableStateOf("bKash") }
    var amountText by remember { mutableStateOf("") }
    var accountHolder by remember { mutableStateOf(currentUser?.fullName ?: "") }
    var accountNumber by remember { mutableStateOf(currentUser?.phone ?: "") }

    val amount = amountText.toDoubleOrNull() ?: 0.0
    val fee = (amount * 1.5) / 100.0
    val netPayout = (amount - fee).coerceAtLeast(0.0)

    Scaffold(
        topBar = {
            ProHeader(
                title = "Withdraw Funds",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("withdraw_screen_scroll"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Balance Overview Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Brush.horizontalGradient(listOf(NavyDark, NavyCard)))
                            .padding(16.dp)
                    ) {
                        Text("Available for Withdrawal", fontSize = 12.sp, color = SlateTextMuted)
                        Text(
                            "৳" + String.format(Locale.US, "%,.2f", currentUser?.availableBalance ?: 0.0),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Pending Reserved Payout: ৳${currentUser?.pendingWithdrawal?.toInt() ?: 0}",
                                fontSize = 11.sp,
                                color = AmberGold
                            )
                            Text("Min. Limit: ৳500", fontSize = 11.sp, color = SlateTextMuted)
                        }
                    }
                }
            }

            // Method Selector
            item {
                Text(
                    "Payout Destination Method",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MethodSelectCard(
                        name = "bKash",
                        icon = Icons.Default.PhoneAndroid,
                        color = Color(0xFFE2136E),
                        isSelected = selectedMethod == "bKash",
                        onClick = { selectedMethod = "bKash" },
                        modifier = Modifier.weight(1f)
                    )
                    MethodSelectCard(
                        name = "Nagad",
                        icon = Icons.Default.SendToMobile,
                        color = Color(0xFFF97316),
                        isSelected = selectedMethod == "Nagad",
                        onClick = { selectedMethod = "Nagad" },
                        modifier = Modifier.weight(1f)
                    )
                    MethodSelectCard(
                        name = "Bank",
                        icon = Icons.Default.AccountBalance,
                        color = ElectricBlue,
                        isSelected = selectedMethod == "Bank",
                        onClick = { selectedMethod = "Bank" },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Withdrawal Form
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "Withdrawal Details",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = it },
                            label = { Text("Withdrawal Amount (৳)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("withdraw_amount_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = accountHolder,
                            onValueChange = { accountHolder = it },
                            label = { Text("Account Holder Name") },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("withdraw_holder_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = accountNumber,
                            onValueChange = { accountNumber = it },
                            label = { Text("Account / Mobile Number") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("withdraw_number_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Fee & Payout summary
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Gateway Fee (1.5%):", fontSize = 11.sp, color = SlateTextSecondary)
                                    Text("৳" + String.format(Locale.US, "%,.2f", fee), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Estimated Net Payout:", fontSize = 11.sp, color = SlateTextSecondary)
                                    Text("৳" + String.format(Locale.US, "%,.2f", netPayout), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = EmeraldSuccess)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                if (amount < 500.0) {
                                    viewModel.showMessage("Minimum withdrawal is ৳500", isError = true)
                                } else if (amount > (currentUser?.availableBalance ?: 0.0)) {
                                    viewModel.showMessage("Insufficient withdrawable funds", isError = true)
                                } else if (accountNumber.isBlank()) {
                                    viewModel.showMessage("Enter valid account details", isError = true)
                                } else {
                                    viewModel.requestWithdrawal(amount, selectedMethod, accountHolder, accountNumber)
                                    amountText = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("submit_withdraw_button")
                        ) {
                            Icon(Icons.Default.ArrowOutward, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Request Payout", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Withdrawal History
            item {
                Text(
                    "Withdrawal Requests",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            if (withdrawHistory.isEmpty()) {
                item {
                    Text(
                        "No withdrawal requests yet.",
                        fontSize = 12.sp,
                        color = SlateTextMuted
                    )
                }
            } else {
                items(withdrawHistory) { tx ->
                    TransactionRow(tx = tx)
                }
            }
        }
    }
}

@Composable
fun MethodSelectCard(
    name: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) color.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            if (isSelected) color else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
        ),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = name, tint = color, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                name,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
