package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(user: UserEntity): Long

    @Update
    suspend fun update(user: UserEntity)

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun getUserById(id: Long): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserByIdDirect(id: Long): UserEntity?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users ORDER BY id DESC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users")
    suspend fun getAllUsersDirect(): List<UserEntity>

    @Query("SELECT COUNT(*) FROM users")
    suspend fun countUsers(): Int
}

@Dao
interface PlanDao {
    @Query("SELECT * FROM investment_plans WHERE isActive = 1 ORDER BY minAmount ASC")
    fun getActivePlans(): Flow<List<InvestmentPlanEntity>>

    @Query("SELECT * FROM investment_plans ORDER BY id ASC")
    fun getAllPlans(): Flow<List<InvestmentPlanEntity>>

    @Query("SELECT * FROM investment_plans WHERE id = :id LIMIT 1")
    suspend fun getPlanById(id: Long): InvestmentPlanEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(plan: InvestmentPlanEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(plans: List<InvestmentPlanEntity>)

    @Update
    suspend fun update(plan: InvestmentPlanEntity)
}

@Dao
interface InvestmentDao {
    @Query("SELECT * FROM investments WHERE userId = :userId ORDER BY startDate DESC")
    fun getInvestmentsForUser(userId: Long): Flow<List<InvestmentEntity>>

    @Query("SELECT * FROM investments WHERE userId = :userId")
    suspend fun getInvestmentsForUserDirect(userId: Long): List<InvestmentEntity>

    @Query("SELECT * FROM investments ORDER BY startDate DESC")
    fun getAllInvestments(): Flow<List<InvestmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(investment: InvestmentEntity): Long

    @Update
    suspend fun update(investment: InvestmentEntity)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions WHERE userId = :userId ORDER BY timestamp DESC")
    fun getTransactionsForUser(userId: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE id = :id LIMIT 1")
    suspend fun getTransactionById(id: Long): TransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(tx: TransactionEntity): Long

    @Update
    suspend fun update(tx: TransactionEntity)
}

@Dao
interface MissionDao {
    @Query("SELECT * FROM daily_missions ORDER BY id ASC")
    fun getAllMissions(): Flow<List<DailyMissionEntity>>

    @Query("SELECT * FROM daily_missions WHERE id = :id LIMIT 1")
    suspend fun getMissionById(id: Long): DailyMissionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(missions: List<DailyMissionEntity>)

    @Update
    suspend fun update(mission: DailyMissionEntity)
}

@Dao
interface ChallengeDao {
    @Query("SELECT * FROM weekly_challenges ORDER BY id ASC")
    fun getAllChallenges(): Flow<List<WeeklyChallengeEntity>>

    @Query("SELECT * FROM weekly_challenges WHERE id = :id LIMIT 1")
    suspend fun getChallengeById(id: Long): WeeklyChallengeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(challenges: List<WeeklyChallengeEntity>)

    @Update
    suspend fun update(challenge: WeeklyChallengeEntity)
}

@Dao
interface AchievementDao {
    @Query("SELECT * FROM achievements ORDER BY id ASC")
    fun getAllAchievements(): Flow<List<AchievementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(achievements: List<AchievementEntity>)

    @Update
    suspend fun update(achievement: AchievementEntity)
}

@Dao
interface SpinHistoryDao {
    @Query("SELECT * FROM spin_history WHERE userId = :userId ORDER BY timestamp DESC LIMIT 20")
    fun getHistoryForUser(userId: Long): Flow<List<SpinHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(history: SpinHistoryEntity): Long
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE userId = :userId ORDER BY timestamp DESC")
    fun getNotificationsForUser(userId: Long): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(notification: NotificationEntity): Long

    @Query("UPDATE notifications SET isRead = 1 WHERE userId = :userId")
    suspend fun markAllAsRead(userId: Long)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: Long)
}

@Dao
interface SupportTicketDao {
    @Query("SELECT * FROM support_tickets WHERE userId = :userId ORDER BY createdAt DESC")
    fun getTicketsForUser(userId: Long): Flow<List<SupportTicketEntity>>

    @Query("SELECT * FROM support_tickets ORDER BY createdAt DESC")
    fun getAllTickets(): Flow<List<SupportTicketEntity>>

    @Query("SELECT * FROM support_tickets WHERE id = :id LIMIT 1")
    suspend fun getTicketById(id: Long): SupportTicketEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(ticket: SupportTicketEntity): Long

    @Update
    suspend fun update(ticket: SupportTicketEntity)
}

@Dao
interface BannerDao {
    @Query("SELECT * FROM promotional_banners WHERE isActive = 1 ORDER BY id ASC")
    fun getActiveBanners(): Flow<List<BannerEntity>>

    @Query("SELECT * FROM promotional_banners ORDER BY id ASC")
    fun getAllBanners(): Flow<List<BannerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(banners: List<BannerEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(banner: BannerEntity): Long

    @Update
    suspend fun update(banner: BannerEntity)
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: AuditLogEntity): Long
}
