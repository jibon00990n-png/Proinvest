package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

data class WheelSegment(
    val label: String,
    val type: String,
    val color: Color
)

@Composable
fun SpinWheelView(
    isSpinning: Boolean,
    spinsAvailable: Int,
    onSpinClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val segments = remember {
        listOf(
            WheelSegment("50 XP", "XP", Color(0xFF3B82F6)),
            WheelSegment("50 Pts", "POINTS", Color(0xFF10B981)),
            WheelSegment("100 XP", "XP", Color(0xFF6366F1)),
            WheelSegment("৳100 Promo", "PROMO", Color(0xFFF59E0B)),
            WheelSegment("200 Pts", "POINTS", Color(0xFFEC4899)),
            WheelSegment("৳250 Cash", "CASH", Color(0xFF101828))
        )
    }

    val rotation = remember { Animatable(0f) }
    val coroutineScope = rememberCoroutineScope()

    // Trigger visual rotation when isSpinning becomes true
    LaunchedEffect(isSpinning) {
        if (isSpinning) {
            val targetDegrees = rotation.value + 360f * 6 + (0..5).random() * 60f
            rotation.animateTo(
                targetValue = targetDegrees,
                animationSpec = tween(
                    durationMillis = 3500,
                    easing = FastOutSlowInEasing
                )
            )
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("spin_wheel_container"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Wheel Box
        Box(
            modifier = Modifier
                .size(280.dp)
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            // Rotating Wheel Canvas
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .rotate(rotation.value)
            ) {
                val canvasSize = size.minDimension
                val radius = canvasSize / 2f
                val center = Offset(size.width / 2f, size.height / 2f)
                val sweepAngle = 360f / segments.size

                // Outer border ring
                drawCircle(
                    color = AmberGold,
                    radius = radius,
                    center = center,
                    style = Stroke(width = 8.dp.toPx())
                )

                // Segments
                segments.forEachIndexed { index, seg ->
                    val startAngle = index * sweepAngle
                    drawArc(
                        color = seg.color,
                        startAngle = startAngle,
                        sweepAngle = sweepAngle,
                        useCenter = true,
                        topLeft = Offset(center.x - radius + 4.dp.toPx(), center.y - radius + 4.dp.toPx()),
                        size = Size((radius - 4.dp.toPx()) * 2, (radius - 4.dp.toPx()) * 2)
                    )
                }

                // Inner divider lines
                segments.indices.forEach { index ->
                    val angleRad = Math.toRadians((index * sweepAngle).toDouble())
                    val endX = center.x + (radius - 4.dp.toPx()) * cos(angleRad).toFloat()
                    val endY = center.y + (radius - 4.dp.toPx()) * sin(angleRad).toFloat()
                    drawLine(
                        color = Color.White.copy(alpha = 0.5f),
                        start = center,
                        end = Offset(endX, endY),
                        strokeWidth = 2.dp.toPx()
                    )
                }

                // Inner center circle
                drawCircle(
                    color = NavyDark,
                    radius = radius * 0.22f,
                    center = center
                )
                drawCircle(
                    color = AmberGold,
                    radius = radius * 0.22f,
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )
            }

            // Top Pointer Needle (Fixed on top pointing down)
            Canvas(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .size(28.dp, 36.dp)
            ) {
                val path = Path().apply {
                    moveTo(size.width / 2f, size.height) // tip pointing down
                    lineTo(0f, 0f)
                    lineTo(size.width, 0f)
                    close()
                }
                drawPath(path, color = AmberGold, style = Fill)
                drawPath(path, color = Color.White, style = Stroke(width = 2.dp.toPx()))
            }

            // Center Star Hub
            Icon(
                Icons.Default.Stars,
                contentDescription = null,
                tint = AmberGold,
                modifier = Modifier
                    .size(36.dp)
                    .shadow(4.dp, CircleShape)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Spin Button
        Button(
            onClick = onSpinClick,
            enabled = !isSpinning && spinsAvailable > 0,
            colors = ButtonDefaults.buttonColors(
                containerColor = AmberGoldDark,
                disabledContainerColor = SlateBorder
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth(0.7f)
                .height(52.dp)
                .testTag("spin_wheel_button")
        ) {
            Icon(
                Icons.Default.Casino,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isSpinning) "Spinning..." else "SPIN NOW ($spinsAvailable Left)",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Probability Segments Disclosure & Legend
        Text(
            "Wheel Rewards & Probabilities",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            LegendPill(color = Color(0xFF3B82F6), label = "50 XP (30%)")
            LegendPill(color = Color(0xFF10B981), label = "50 Pts (25%)")
            LegendPill(color = Color(0xFF6366F1), label = "100 XP (20%)")
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            LegendPill(color = Color(0xFFF59E0B), label = "৳100 Promo (15%)")
            LegendPill(color = Color(0xFFEC4899), label = "200 Pts (8%)")
            LegendPill(color = Color(0xFF101828), label = "৳250 Cash (2%)")
        }
    }
}

@Composable
fun LegendPill(color: Color, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            label,
            fontSize = 11.sp,
            color = SlateTextSecondary,
            fontWeight = FontWeight.Medium
        )
    }
}
