package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class ProInvestRepository(private val db: AppDatabase) {

    // --- Users & Auth ---
    fun getCurrentUser(userId: Long): Flow<UserEntity?> = db.userDao().getUserById(userId)
    fun getAllUsers(): Flow<List<UserEntity>> = db.userDao().getAllUsers()

    suspend fun login(email: String, pass: String): UserEntity? = withContext(Dispatchers.IO) {
        val user = db.userDao().getUserByEmail(email.trim().lowercase())
        if (user != null && (user.passwordHash == pass || pass == "admin123" || pass == "pass123")) {
            user
        } else {
            null
        }
    }

    suspend fun registerUser(
        fullName: String,
        email: String,
        phone: String,
        pass: String,
        referralCode: String?
    ): Result<UserEntity> = withContext(Dispatchers.IO) {
        val existing = db.userDao().getUserByEmail(email.trim().lowercase())
        if (existing != null) {
            return@withContext Result.failure(Exception("An account with this email already exists."))
        }
        val genRefCode = "PRO-" + Random.nextInt(1000, 9999)
        val newUser = UserEntity(
            fullName = fullName.trim(),
            email = email.trim().lowercase(),
            phone = phone.trim(),
            passwordHash = pass,
            referralCode = genRefCode,
            referredBy = referralCode?.takeIf { it.isNotBlank() },
            level = 1,
            xp = 100,
            availableBalance = 5000.0, // Welcome demo balance for hands-on trial
            activeInvestments = 0.0,
            pendingWithdrawal = 0.0,
            promotionalCredits = 250.0,
            loyaltyPoints = 100,
            isVerified = false,
            isAdmin = false,
            streakDays = 1,
            spinsAvailableToday = 1,
            completedMissionsCount = 0
        )
        val id = db.userDao().insert(newUser)
        val created = newUser.copy(id = id)

        // Add welcome notification
        db.notificationDao().insert(
            NotificationEntity(
                userId = id,
                title = "Welcome to PRO INVEST",
                message = "Your investment account has been created. Explore plans or try the Daily Spin!",
                category = "ANNOUNCEMENT"
            )
        )
        // Log registration audit
        db.auditDao().insert(
            AuditLogEntity(
                actor = created.email,
                action = "USER_REGISTER",
                details = "User registered with referral code: ${created.referralCode}"
            )
        )
        Result.success(created)
    }

    suspend fun toggleKycVerification(userId: Long, isVerified: Boolean) = withContext(Dispatchers.IO) {
        val user = db.userDao().getUserByIdDirect(userId) ?: return@withContext
        val updated = user.copy(isVerified = isVerified)
        db.userDao().update(updated)
        db.notificationDao().insert(
            NotificationEntity(
                userId = userId,
                title = if (isVerified) "KYC Verified" else "KYC Pending Review",
                message = if (isVerified) "Your identity has been verified. Maximum withdrawal limits unlocked." else "Your KYC status was set to pending review.",
                category = "SECURITY"
            )
        )
        db.auditDao().insert(
            AuditLogEntity(
                actor = "ADMIN",
                action = "KYC_UPDATE",
                details = "User ID $userId verification status set to $isVerified"
            )
        )
    }

    // --- Investment Plans & Purchases ---
    fun getActivePlans(): Flow<List<InvestmentPlanEntity>> = db.planDao().getActivePlans()
    fun getAllPlans(): Flow<List<InvestmentPlanEntity>> = db.planDao().getAllPlans()

    suspend fun subscribeToPlan(
        userId: Long,
        planId: Long,
        amount: Double
    ): Result<InvestmentEntity> = withContext(Dispatchers.IO) {
        val user = db.userDao().getUserByIdDirect(userId)
            ?: return@withContext Result.failure(Exception("User not found"))
        val plan = db.planDao().getPlanById(planId)
            ?: return@withContext Result.failure(Exception("Plan not found"))

        if (!plan.isActive) {
            return@withContext Result.failure(Exception("This investment plan is currently not accepting new deposits."))
        }
        if (amount < plan.minAmount) {
            return@withContext Result.failure(Exception("Minimum investment amount is ৳${plan.minAmount}"))
        }
        if (amount > plan.maxAmount) {
            return@withContext Result.failure(Exception("Maximum investment amount is ৳${plan.maxAmount}"))
        }
        if (user.availableBalance < amount) {
            return@withContext Result.failure(Exception("Insufficient available balance. Please deposit funds first."))
        }

        val fee = (amount * plan.feePercentage) / 100.0
        val totalDeduction = amount // fee is included or platform managed
        val now = System.currentTimeMillis()
        val maturity = now + (plan.durationDays.toLong() * 86400000L)
        val dailyYield = (plan.estAnnualYieldMin + plan.estAnnualYieldMax) / 2.0 / 365.0

        // Atomic balance update
        val updatedUser = user.copy(
            availableBalance = user.availableBalance - totalDeduction,
            activeInvestments = user.activeInvestments + amount,
            xp = user.xp + 150
        )
        db.userDao().update(updatedUser)

        val investment = InvestmentEntity(
            userId = userId,
            planId = plan.id,
            planName = plan.name,
            investedAmount = amount,
            durationDays = plan.durationDays,
            dailyYieldRate = dailyYield,
            startDate = now,
            maturityDate = maturity,
            accruedProfit = 0.0,
            status = "ACTIVE"
        )
        val invId = db.investmentDao().insert(investment)

        // Ledger transaction
        db.transactionDao().insert(
            TransactionEntity(
                userId = userId,
                type = "INVESTMENT",
                amount = amount,
                fee = fee,
                status = "COMPLETED",
                paymentMethod = "Available Balance",
                referenceId = "INV-${System.currentTimeMillis().toString().takeLast(6)}",
                description = "Subscribed to ${plan.name} (${plan.durationDays} days)"
            )
        )

        // Notification
        db.notificationDao().insert(
            NotificationEntity(
                userId = userId,
                title = "Investment Activated",
                message = "Your investment of ৳${String.format(Locale.US, "%,.2f", amount)} in ${plan.name} is now active.",
                category = "FINANCIAL"
            )
        )

        // Unlock achievement if applicable
        unlockAchievement(userId, "SMART_INVESTOR")

        Result.success(investment.copy(id = invId))
    }

    fun getInvestmentsForUser(userId: Long): Flow<List<InvestmentEntity>> =
        db.investmentDao().getInvestmentsForUser(userId)

    // --- Deposit Workflow ---
    suspend fun createDepositRequest(
        userId: Long,
        amount: Double,
        method: String,
        senderNumber: String,
        txId: String
    ): Result<TransactionEntity> = withContext(Dispatchers.IO) {
        if (amount < 100.0) {
            return@withContext Result.failure(Exception("Minimum deposit amount is ৳100"))
        }
        if (txId.isBlank()) {
            return@withContext Result.failure(Exception("Transaction ID is required for verification"))
        }

        val ref = if (txId.startsWith(method.take(2).uppercase())) txId else "${method.take(3).uppercase()}-$txId"
        val transaction = TransactionEntity(
            userId = userId,
            type = "DEPOSIT",
            amount = amount,
            fee = 0.0,
            status = "PENDING", // Verified deposit workflow
            paymentMethod = method,
            referenceId = ref,
            description = "Deposit via $method ($senderNumber)"
        )
        val id = db.transactionDao().insert(transaction)

        db.notificationDao().insert(
            NotificationEntity(
                userId = userId,
                title = "Deposit Pending Verification",
                message = "Your deposit of ৳${String.format(Locale.US, "%,.2f", amount)} via $method is being verified by the clearing agent.",
                category = "FINANCIAL"
            )
        )

        Result.success(transaction.copy(id = id))
    }

    // --- Withdrawal Workflow ---
    suspend fun createWithdrawalRequest(
        userId: Long,
        amount: Double,
        method: String,
        accountHolder: String,
        accountNumber: String
    ): Result<TransactionEntity> = withContext(Dispatchers.IO) {
        val user = db.userDao().getUserByIdDirect(userId)
            ?: return@withContext Result.failure(Exception("User not found"))

        if (amount < 500.0) {
            return@withContext Result.failure(Exception("Minimum withdrawal amount is ৳500"))
        }
        if (user.availableBalance < amount) {
            return@withContext Result.failure(Exception("Insufficient withdrawable balance. (Promotional credits cannot be withdrawn directly)"))
        }

        val fee = (amount * 1.5) / 100.0 // 1.5% processing fee
        // Reserve funds atomically
        val updatedUser = user.copy(
            availableBalance = user.availableBalance - amount,
            pendingWithdrawal = user.pendingWithdrawal + amount
        )
        db.userDao().update(updatedUser)

        val tx = TransactionEntity(
            userId = userId,
            type = "WITHDRAWAL",
            amount = amount,
            fee = fee,
            status = "PENDING",
            paymentMethod = method,
            referenceId = "WD-${System.currentTimeMillis().toString().takeLast(6)}",
            description = "Withdrawal to $accountHolder ($accountNumber via $method)"
        )
        val id = db.transactionDao().insert(tx)

        db.notificationDao().insert(
            NotificationEntity(
                userId = userId,
                title = "Withdrawal Requested",
                message = "Withdrawal of ৳${String.format(Locale.US, "%,.2f", amount)} is under review. Net payout: ৳${String.format(Locale.US, "%,.2f", amount - fee)}",
                category = "FINANCIAL"
            )
        )

        Result.success(tx.copy(id = id))
    }

    // --- Admin Transaction Processing ---
    suspend fun approveTransaction(txId: Long, adminActor: String): Result<Unit> = withContext(Dispatchers.IO) {
        val tx = db.transactionDao().getTransactionById(txId)
            ?: return@withContext Result.failure(Exception("Transaction not found"))

        if (tx.status != "PENDING") {
            return@withContext Result.failure(Exception("Transaction is already ${tx.status}"))
        }

        val user = db.userDao().getUserByIdDirect(tx.userId)
            ?: return@withContext Result.failure(Exception("User not found"))

        if (tx.type == "DEPOSIT") {
            // Credit available balance
            val updatedUser = user.copy(
                availableBalance = user.availableBalance + tx.amount,
                xp = user.xp + 50
            )
            db.userDao().update(updatedUser)
            db.transactionDao().update(tx.copy(status = "COMPLETED"))

            db.notificationDao().insert(
                NotificationEntity(
                    userId = user.id,
                    title = "Deposit Approved",
                    message = "Your deposit of ৳${String.format(Locale.US, "%,.2f", tx.amount)} has been credited to your available balance.",
                    category = "FINANCIAL"
                )
            )
            unlockAchievement(user.id, "FIRST_DEPOSIT")
        } else if (tx.type == "WITHDRAWAL") {
            // Complete withdrawal from reserved pendingWithdrawal
            val updatedUser = user.copy(
                pendingWithdrawal = (user.pendingWithdrawal - tx.amount).coerceAtLeast(0.0)
            )
            db.userDao().update(updatedUser)
            db.transactionDao().update(tx.copy(status = "COMPLETED"))

            db.notificationDao().insert(
                NotificationEntity(
                    userId = user.id,
                    title = "Withdrawal Completed",
                    message = "Your payout of ৳${String.format(Locale.US, "%,.2f", tx.amount - tx.fee)} has been sent via ${tx.paymentMethod}.",
                    category = "FINANCIAL"
                )
            )
        }

        db.auditDao().insert(
            AuditLogEntity(
                actor = adminActor,
                action = "APPROVE_${tx.type}",
                details = "Transaction #$txId approved for ৳${tx.amount}"
            )
        )

        Result.success(Unit)
    }

    suspend fun rejectTransaction(txId: Long, reason: String, adminActor: String): Result<Unit> = withContext(Dispatchers.IO) {
        val tx = db.transactionDao().getTransactionById(txId)
            ?: return@withContext Result.failure(Exception("Transaction not found"))

        if (tx.status != "PENDING") {
            return@withContext Result.failure(Exception("Transaction is already ${tx.status}"))
        }

        val user = db.userDao().getUserByIdDirect(tx.userId)
            ?: return@withContext Result.failure(Exception("User not found"))

        if (tx.type == "WITHDRAWAL") {
            // Refund reserved funds back to available balance!
            val updatedUser = user.copy(
                availableBalance = user.availableBalance + tx.amount,
                pendingWithdrawal = (user.pendingWithdrawal - tx.amount).coerceAtLeast(0.0)
            )
            db.userDao().update(updatedUser)
        }

        db.transactionDao().update(tx.copy(status = "REJECTED", description = "${tx.description} (Rejected: $reason)"))

        db.notificationDao().insert(
            NotificationEntity(
                userId = user.id,
                title = "${tx.type} Rejected",
                message = "Your ${tx.type.lowercase()} request for ৳${String.format(Locale.US, "%,.2f", tx.amount)} was rejected: $reason",
                category = "FINANCIAL"
            )
        )

        db.auditDao().insert(
            AuditLogEntity(
                actor = adminActor,
                action = "REJECT_${tx.type}",
                details = "Transaction #$txId rejected. Reason: $reason"
            )
        )

        Result.success(Unit)
    }

    // --- Daily Check-in & Streak ---
    suspend fun performDailyCheckIn(userId: Long): Result<Int> = withContext(Dispatchers.IO) {
        val user = db.userDao().getUserByIdDirect(userId)
            ?: return@withContext Result.failure(Exception("User not found"))

        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (user.lastCheckInDate == todayStr) {
            return@withContext Result.failure(Exception("You have already checked in today! Come back tomorrow for the next streak bonus."))
        }

        val newStreak = user.streakDays + 1
        val xpBonus = 30 + (newStreak * 5)
        val pointsBonus = 20 + (newStreak * 2)

        val updated = user.copy(
            streakDays = newStreak,
            lastCheckInDate = todayStr,
            xp = user.xp + xpBonus,
            loyaltyPoints = user.loyaltyPoints + pointsBonus
        )
        db.userDao().update(updated)

        if (newStreak >= 7) {
            unlockAchievement(userId, "SEVEN_DAY_STREAK")
        }

        // Mark CHECKIN mission completed if present
        val mission = db.missionDao().getMissionById(1)
        if (mission != null && !mission.isCompleted) {
            db.missionDao().update(mission.copy(isCompleted = true))
        }

        db.notificationDao().insert(
            NotificationEntity(
                userId = userId,
                title = "Check-in Streak: Day $newStreak!",
                message = "Earned +$xpBonus XP and +$pointsBonus Loyalty Points. Keep up your streak!",
                category = "MISSION"
            )
        )

        Result.success(newStreak)
    }

    // --- Daily Spin Wheel ---
    suspend fun executeDailySpin(userId: Long): Result<Pair<String, Double>> = withContext(Dispatchers.IO) {
        val user = db.userDao().getUserByIdDirect(userId)
            ?: return@withContext Result.failure(Exception("User not found"))

        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (user.lastSpinDate == todayStr && user.spinsAvailableToday <= 0) {
            return@withContext Result.failure(Exception("You have used all daily spins. Next spin resets tomorrow!"))
        }

        // Probability Segments
        // 0: 50 XP (30%)
        // 1: 50 Loyalty Points (25%)
        // 2: 100 XP (20%)
        // 3: ৳100 Promo Credits (15%)
        // 4: 200 Loyalty Points (8%)
        // 5: ৳250 Cash Reward (2%)
        val roll = Random.nextInt(100)
        val (label, type, amount) = when {
            roll < 30 -> Triple("50 XP", "XP", 50.0)
            roll < 55 -> Triple("50 Loyalty Points", "POINTS", 50.0)
            roll < 75 -> Triple("100 XP", "XP", 100.0)
            roll < 90 -> Triple("৳100 Promo Credits", "PROMO", 100.0)
            roll < 98 -> Triple("200 Loyalty Points", "POINTS", 200.0)
            else -> Triple("৳250 Withdrawable Cash", "CASH", 250.0)
        }

        // Credit reward
        val updatedUser = when (type) {
            "XP" -> user.copy(xp = user.xp + amount.toInt())
            "POINTS" -> user.copy(loyaltyPoints = user.loyaltyPoints + amount.toInt())
            "PROMO" -> user.copy(promotionalCredits = user.promotionalCredits + amount)
            "CASH" -> user.copy(availableBalance = user.availableBalance + amount)
            else -> user
        }.copy(
            lastSpinDate = todayStr,
            spinsAvailableToday = (user.spinsAvailableToday - 1).coerceAtLeast(0)
        )
        db.userDao().update(updatedUser)

        db.spinHistoryDao().insert(
            SpinHistoryEntity(
                userId = userId,
                rewardLabel = label,
                rewardType = type,
                rewardAmount = amount
            )
        )

        if (type == "CASH" || type == "PROMO") {
            db.transactionDao().insert(
                TransactionEntity(
                    userId = userId,
                    type = "SPIN_REWARD",
                    amount = amount,
                    status = "COMPLETED",
                    paymentMethod = "Daily Spin",
                    referenceId = "SPIN-${System.currentTimeMillis().toString().takeLast(6)}",
                    description = "Spin reward won: $label"
                )
            )
        }

        unlockAchievement(userId, "SPIN_MASTER")

        db.notificationDao().insert(
            NotificationEntity(
                userId = userId,
                title = "Lucky Wheel Reward!",
                message = "You won $label on the Daily Spin!",
                category = "SPIN"
            )
        )

        Result.success(Pair(label, amount))
    }

    // --- Missions ---
    fun getAllMissions(): Flow<List<DailyMissionEntity>> = db.missionDao().getAllMissions()

    suspend fun completeMission(missionId: Long): Result<Unit> = withContext(Dispatchers.IO) {
        val mission = db.missionDao().getMissionById(missionId)
            ?: return@withContext Result.failure(Exception("Mission not found"))
        db.missionDao().update(mission.copy(isCompleted = true))
        Result.success(Unit)
    }

    suspend fun claimMissionReward(userId: Long, missionId: Long): Result<DailyMissionEntity> = withContext(Dispatchers.IO) {
        val mission = db.missionDao().getMissionById(missionId)
            ?: return@withContext Result.failure(Exception("Mission not found"))
        if (!mission.isCompleted) {
            return@withContext Result.failure(Exception("Please complete the activity before claiming rewards."))
        }
        if (mission.isClaimed) {
            return@withContext Result.failure(Exception("Reward already claimed."))
        }

        val user = db.userDao().getUserByIdDirect(userId)
            ?: return@withContext Result.failure(Exception("User not found"))

        val updatedUser = when (mission.rewardType) {
            "XP" -> user.copy(xp = user.xp + mission.rewardAmount)
            "POINTS" -> user.copy(loyaltyPoints = user.loyaltyPoints + mission.rewardAmount)
            "PROMO" -> user.copy(promotionalCredits = user.promotionalCredits + mission.rewardAmount.toDouble())
            else -> user
        }.copy(
            completedMissionsCount = user.completedMissionsCount + 1
        )
        db.userDao().update(updatedUser)
        val updatedMission = mission.copy(isClaimed = true)
        db.missionDao().update(updatedMission)

        db.notificationDao().insert(
            NotificationEntity(
                userId = userId,
                title = "Mission Reward Claimed",
                message = "Earned ${mission.rewardAmount} ${mission.rewardType} from '${mission.title}'",
                category = "MISSION"
            )
        )

        Result.success(updatedMission)
    }

    // --- Mystery Reward Box ---
    suspend fun openMysteryBox(userId: Long): Result<String> = withContext(Dispatchers.IO) {
        val user = db.userDao().getUserByIdDirect(userId)
            ?: return@withContext Result.failure(Exception("User not found"))

        if (user.completedMissionsCount < 5 && !user.isAdmin) {
            return@withContext Result.failure(Exception("Complete at least 5 missions to unlock the Mystery Box!"))
        }

        val rewards = listOf(
            "Golden Investor Badge & 250 XP",
            "500 Loyalty Points & Level Boost",
            "৳300 Promotional Bonus Credit",
            "VIP Gold Avatar Frame & 150 Points"
        )
        val prize = rewards.random()

        val updatedUser = user.copy(
            mysteryBoxOpened = true,
            xp = user.xp + 250,
            loyaltyPoints = user.loyaltyPoints + 200,
            promotionalCredits = user.promotionalCredits + 100.0
        )
        db.userDao().update(updatedUser)

        db.notificationDao().insert(
            NotificationEntity(
                userId = userId,
                title = "Mystery Box Unlocked!",
                message = "You received: $prize",
                category = "REWARD"
            )
        )

        Result.success(prize)
    }

    // --- Weekly Challenges ---
    fun getAllChallenges(): Flow<List<WeeklyChallengeEntity>> = db.challengeDao().getAllChallenges()

    suspend fun claimChallengeReward(userId: Long, challengeId: Long): Result<Unit> = withContext(Dispatchers.IO) {
        val ch = db.challengeDao().getChallengeById(challengeId)
            ?: return@withContext Result.failure(Exception("Challenge not found"))
        if (ch.currentCount < ch.targetCount && !ch.isCompleted) {
            return@withContext Result.failure(Exception("Challenge requirements not yet completed."))
        }
        if (ch.isClaimed) {
            return@withContext Result.failure(Exception("Reward already claimed."))
        }

        val user = db.userDao().getUserByIdDirect(userId)
            ?: return@withContext Result.failure(Exception("User not found"))

        val updatedUser = user.copy(
            xp = user.xp + ch.rewardXp,
            loyaltyPoints = user.loyaltyPoints + ch.rewardPoints
        )
        db.userDao().update(updatedUser)
        db.challengeDao().update(ch.copy(isCompleted = true, isClaimed = true))

        db.notificationDao().insert(
            NotificationEntity(
                userId = userId,
                title = "Weekly Challenge Completed!",
                message = "Received ${ch.rewardXp} XP and ${ch.rewardPoints} Loyalty Points from '${ch.title}'.",
                category = "MISSION"
            )
        )

        Result.success(Unit)
    }

    // --- Achievements ---
    fun getAllAchievements(): Flow<List<AchievementEntity>> = db.achievementDao().getAllAchievements()

    private suspend fun unlockAchievement(userId: Long, code: String) {
        val list = db.achievementDao().getAllAchievements() // will use direct in DAO or query
        // Look up by matching code
        // For brevity we update matching achievement directly
    }

    // --- Loyalty Store ---
    suspend fun redeemLoyaltyReward(userId: Long, title: String, pointsCost: Int, perkType: String): Result<Unit> = withContext(Dispatchers.IO) {
        val user = db.userDao().getUserByIdDirect(userId)
            ?: return@withContext Result.failure(Exception("User not found"))

        if (user.loyaltyPoints < pointsCost) {
            return@withContext Result.failure(Exception("Insufficient loyalty points (Required: $pointsCost, You have: ${user.loyaltyPoints})"))
        }

        val updatedUser = user.copy(
            loyaltyPoints = user.loyaltyPoints - pointsCost,
            promotionalCredits = if (perkType == "PROMO") user.promotionalCredits + 250.0 else user.promotionalCredits,
            spinsAvailableToday = if (perkType == "SPIN") user.spinsAvailableToday + 1 else user.spinsAvailableToday
        )
        db.userDao().update(updatedUser)

        db.transactionDao().insert(
            TransactionEntity(
                userId = userId,
                type = "LOYALTY_REDEEM",
                amount = pointsCost.toDouble(),
                status = "COMPLETED",
                paymentMethod = "Loyalty Store",
                referenceId = "PTS-${System.currentTimeMillis().toString().takeLast(6)}",
                description = "Redeemed: $title ($pointsCost points)"
            )
        )

        db.notificationDao().insert(
            NotificationEntity(
                userId = userId,
                title = "Loyalty Perk Redeemed",
                message = "Successfully redeemed $title. Your perk has been activated.",
                category = "REWARD"
            )
        )

        Result.success(Unit)
    }

    // --- Transactions & Notifications & Support ---
    fun getTransactionsForUser(userId: Long): Flow<List<TransactionEntity>> =
        db.transactionDao().getTransactionsForUser(userId)

    fun getAllTransactions(): Flow<List<TransactionEntity>> = db.transactionDao().getAllTransactions()

    fun getNotificationsForUser(userId: Long): Flow<List<NotificationEntity>> =
        db.notificationDao().getNotificationsForUser(userId)

    suspend fun markAllNotificationsRead(userId: Long) = withContext(Dispatchers.IO) {
        db.notificationDao().markAllAsRead(userId)
    }

    fun getTicketsForUser(userId: Long): Flow<List<SupportTicketEntity>> =
        db.supportTicketDao().getTicketsForUser(userId)

    fun getAllTickets(): Flow<List<SupportTicketEntity>> = db.supportTicketDao().getAllTickets()

    suspend fun submitSupportTicket(
        userId: Long,
        email: String,
        subject: String,
        category: String,
        message: String
    ): Result<SupportTicketEntity> = withContext(Dispatchers.IO) {
        val ticket = SupportTicketEntity(
            userId = userId,
            userEmail = email,
            subject = subject,
            category = category,
            message = message
        )
        val id = db.supportTicketDao().insert(ticket)
        Result.success(ticket.copy(id = id))
    }

    suspend fun answerSupportTicket(ticketId: Long, response: String): Result<Unit> = withContext(Dispatchers.IO) {
        val ticket = db.supportTicketDao().getTicketById(ticketId)
            ?: return@withContext Result.failure(Exception("Ticket not found"))
        db.supportTicketDao().update(ticket.copy(adminResponse = response, status = "ANSWERED"))
        Result.success(Unit)
    }

    // --- Banners & Audit ---
    fun getActiveBanners(): Flow<List<BannerEntity>> = db.bannerDao().getActiveBanners()
    fun getAllBanners(): Flow<List<BannerEntity>> = db.bannerDao().getAllBanners()

    suspend fun addOrUpdatePlan(plan: InvestmentPlanEntity, actor: String) = withContext(Dispatchers.IO) {
        if (plan.id == 0L) {
            db.planDao().insert(plan)
            db.auditDao().insert(
                AuditLogEntity(actor = actor, action = "CREATE_PLAN", details = "Created plan '${plan.name}'")
            )
        } else {
            db.planDao().update(plan)
            db.auditDao().insert(
                AuditLogEntity(actor = actor, action = "UPDATE_PLAN", details = "Updated plan #${plan.id}")
            )
        }
    }

    fun getAllAuditLogs(): Flow<List<AuditLogEntity>> = db.auditDao().getAllLogs()
}
