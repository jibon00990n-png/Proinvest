package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        InvestmentPlanEntity::class,
        InvestmentEntity::class,
        TransactionEntity::class,
        DailyMissionEntity::class,
        WeeklyChallengeEntity::class,
        AchievementEntity::class,
        SpinHistoryEntity::class,
        NotificationEntity::class,
        SupportTicketEntity::class,
        BannerEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun planDao(): PlanDao
    abstract fun investmentDao(): InvestmentDao
    abstract fun transactionDao(): TransactionDao
    abstract fun missionDao(): MissionDao
    abstract fun challengeDao(): ChallengeDao
    abstract fun achievementDao(): AchievementDao
    abstract fun spinHistoryDao(): SpinHistoryDao
    abstract fun notificationDao(): NotificationDao
    abstract fun supportTicketDao(): SupportTicketDao
    abstract fun bannerDao(): BannerDao
    abstract fun auditDao(): AuditDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pro_invest_database"
                )
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database)
                    }
                }
            }
        }

        suspend fun populateInitialData(db: AppDatabase) {
            // Seed Users
            val user1Id = db.userDao().insert(
                UserEntity(
                    id = 1,
                    fullName = "Zubair Rahman",
                    email = "user@proinvest.com",
                    phone = "+880 1712 345678",
                    passwordHash = "pass123",
                    referralCode = "PRO-7892",
                    referredBy = null,
                    level = 2,
                    xp = 380,
                    availableBalance = 25000.0,
                    activeInvestments = 15000.0,
                    pendingWithdrawal = 0.0,
                    promotionalCredits = 800.0,
                    loyaltyPoints = 450,
                    isVerified = true,
                    isAdmin = false,
                    streakDays = 4,
                    lastCheckInDate = "",
                    spinsAvailableToday = 1,
                    completedMissionsCount = 3
                )
            )

            db.userDao().insert(
                UserEntity(
                    id = 2,
                    fullName = "Super Administrator",
                    email = "admin@proinvest.com",
                    phone = "+880 1999 000111",
                    passwordHash = "admin123",
                    referralCode = "ADM-0001",
                    referredBy = null,
                    level = 5,
                    xp = 2800,
                    availableBalance = 250000.0,
                    activeInvestments = 80000.0,
                    pendingWithdrawal = 0.0,
                    promotionalCredits = 5000.0,
                    loyaltyPoints = 3200,
                    isVerified = true,
                    isAdmin = true,
                    streakDays = 15,
                    lastCheckInDate = "",
                    spinsAvailableToday = 3,
                    completedMissionsCount = 10
                )
            )

            // Seed Investment Plans
            db.planDao().insertAll(
                listOf(
                    InvestmentPlanEntity(
                        id = 1,
                        name = "Smart Starter Yield",
                        category = "STARTER",
                        minAmount = 1000.0,
                        maxAmount = 15000.0,
                        durationDays = 14,
                        estAnnualYieldMin = 6.5,
                        estAnnualYieldMax = 8.5,
                        feePercentage = 0.5,
                        riskLevel = "Low Risk",
                        description = "Diversified short-term treasury bills & liquid corporate commercial papers.",
                        terms = "Daily yield accrual with principal lock-in for 14 calendar days. Penalty-free return of capital at maturity."
                    ),
                    InvestmentPlanEntity(
                        id = 2,
                        name = "Green Horizon Growth",
                        category = "GROWTH",
                        minAmount = 5000.0,
                        maxAmount = 50000.0,
                        durationDays = 30,
                        estAnnualYieldMin = 10.0,
                        estAnnualYieldMax = 13.5,
                        feePercentage = 0.8,
                        riskLevel = "Moderate",
                        description = "Direct allocation into renewable solar parks and municipal green infrastructure bonds.",
                        terms = "Quarterly audited yields. Return credited daily to available balance."
                    ),
                    InvestmentPlanEntity(
                        id = 3,
                        name = "Apex Tech Growth Fund",
                        category = "GROWTH",
                        minAmount = 10000.0,
                        maxAmount = 100000.0,
                        durationDays = 60,
                        estAnnualYieldMin = 14.0,
                        estAnnualYieldMax = 18.0,
                        feePercentage = 1.0,
                        riskLevel = "Moderate",
                        description = "Equity and debt exposure to vetted fintech, cloud services, and logistics hubs.",
                        terms = "60-day tenure. Yield calculated based on portfolio asset revenues."
                    ),
                    InvestmentPlanEntity(
                        id = 4,
                        name = "Sovereign Blue Chip",
                        category = "PREMIUM",
                        minAmount = 25000.0,
                        maxAmount = 500000.0,
                        durationDays = 90,
                        estAnnualYieldMin = 17.5,
                        estAnnualYieldMax = 22.0,
                        feePercentage = 1.2,
                        riskLevel = "Dynamic",
                        description = "Institutional asset-backed securities and trade finance contracts.",
                        terms = "Full capital collateralization. Designed for experienced high-tier investors."
                    )
                )
            )

            // Seed User 1 Investment
            val now = System.currentTimeMillis()
            db.investmentDao().insert(
                InvestmentEntity(
                    id = 1,
                    userId = 1,
                    planId = 2,
                    planName = "Green Horizon Growth",
                    investedAmount = 15000.0,
                    durationDays = 30,
                    dailyYieldRate = 0.033, // ~12% annual / 365
                    startDate = now - (12L * 86400000L),
                    maturityDate = now + (18L * 86400000L),
                    accruedProfit = 594.0,
                    status = "ACTIVE"
                )
            )

            // Seed Transactions
            db.transactionDao().insert(
                TransactionEntity(
                    userId = 1,
                    type = "DEPOSIT",
                    amount = 40000.0,
                    fee = 0.0,
                    status = "COMPLETED",
                    paymentMethod = "bKash",
                    referenceId = "BK-99238104",
                    description = "Mobile money wallet deposit verified",
                    timestamp = now - (14L * 86400000L)
                )
            )
            db.transactionDao().insert(
                TransactionEntity(
                    userId = 1,
                    type = "INVESTMENT",
                    amount = 15000.0,
                    fee = 120.0,
                    status = "COMPLETED",
                    paymentMethod = "Available Balance",
                    referenceId = "INV-20261014-01",
                    description = "Subscribed to Green Horizon Growth (30 days)",
                    timestamp = now - (12L * 86400000L)
                )
            )
            db.transactionDao().insert(
                TransactionEntity(
                    userId = 1,
                    type = "SPIN_REWARD",
                    amount = 50.0,
                    fee = 0.0,
                    status = "COMPLETED",
                    paymentMethod = "Daily Spin",
                    referenceId = "SPIN-8812",
                    description = "Won 50 Loyalty Points on Daily Wheel",
                    timestamp = now - (1L * 86400000L)
                )
            )
            // A pending deposit for testing admin approval
            db.transactionDao().insert(
                TransactionEntity(
                    userId = 1,
                    type = "DEPOSIT",
                    amount = 5000.0,
                    fee = 0.0,
                    status = "PENDING",
                    paymentMethod = "Nagad",
                    referenceId = "NAG-44182901",
                    description = "Deposit via Nagad agent transfer",
                    timestamp = now - 3600000L
                )
            )

            // Seed Missions
            db.missionDao().insertAll(
                listOf(
                    DailyMissionEntity(
                        id = 1,
                        missionCode = "CHECKIN",
                        title = "Daily Check-in",
                        description = "Log in today to preserve your 7-day reward streak.",
                        timeEstimate = "5 sec",
                        rewardType = "XP",
                        rewardAmount = 50,
                        missionType = "CHECKIN",
                        isCompleted = false,
                        isClaimed = false,
                        details = "Collect streak bonus every consecutive day."
                    ),
                    DailyMissionEntity(
                        id = 2,
                        missionCode = "QUIZ",
                        title = "Daily Financial Quiz",
                        description = "Test your knowledge on compounding interest and inflation.",
                        timeEstimate = "30 sec",
                        rewardType = "POINTS",
                        rewardAmount = 40,
                        missionType = "QUIZ",
                        isCompleted = false,
                        isClaimed = false,
                        details = "What is the Rule of 72 used for in personal finance?"
                    ),
                    DailyMissionEntity(
                        id = 3,
                        missionCode = "TIP",
                        title = "Read Financial Tip",
                        description = "Understand portfolio diversification to minimize risk.",
                        timeEstimate = "45 sec",
                        rewardType = "XP",
                        rewardAmount = 35,
                        missionType = "TIP",
                        isCompleted = true,
                        isClaimed = true,
                        details = "Diversification is the practice of spreading your investments around so that your exposure to any one type of asset is limited."
                    ),
                    DailyMissionEntity(
                        id = 4,
                        missionCode = "SECURITY",
                        title = "Review Account Security",
                        description = "Ensure strong authentication and active session hygiene.",
                        timeEstimate = "20 sec",
                        rewardType = "XP",
                        rewardAmount = 30,
                        missionType = "SECURITY",
                        isCompleted = true,
                        isClaimed = true,
                        details = "Never share your PIN, OTP, or passwords with anyone claiming to represent support."
                    ),
                    DailyMissionEntity(
                        id = 5,
                        missionCode = "ANNOUNCEMENT",
                        title = "View Daily Bulletin",
                        description = "Stay informed on platform regulatory updates and audit results.",
                        timeEstimate = "15 sec",
                        rewardType = "POINTS",
                        rewardAmount = 25,
                        missionType = "ANNOUNCEMENT",
                        isCompleted = false,
                        isClaimed = false,
                        details = "Quarterly financial reserves audit report is now published under Help & Support."
                    )
                )
            )

            // Seed Weekly Challenges
            db.challengeDao().insertAll(
                listOf(
                    WeeklyChallengeEntity(
                        id = 1,
                        title = "Quiz Master Challenge",
                        description = "Complete 5 daily financial literacy quizzes this week.",
                        targetCount = 5,
                        currentCount = 3,
                        rewardXp = 150,
                        rewardPoints = 100,
                        isCompleted = false,
                        isClaimed = false,
                        endDateStr = "Sunday, 23:59"
                    ),
                    WeeklyChallengeEntity(
                        id = 2,
                        title = "Check-in Streak Pioneer",
                        description = "Maintain active daily check-ins for 5 days in a row.",
                        targetCount = 5,
                        currentCount = 4,
                        rewardXp = 200,
                        rewardPoints = 150,
                        isCompleted = false,
                        isClaimed = false,
                        endDateStr = "Sunday, 23:59"
                    ),
                    WeeklyChallengeEntity(
                        id = 3,
                        title = "Education Enthusiast",
                        description = "Read 3 educational modules and financial tips.",
                        targetCount = 3,
                        currentCount = 3,
                        rewardXp = 120,
                        rewardPoints = 80,
                        isCompleted = true,
                        isClaimed = false,
                        endDateStr = "Sunday, 23:59"
                    )
                )
            )

            // Seed Achievements
            db.achievementDao().insertAll(
                listOf(
                    AchievementEntity(
                        id = 1,
                        code = "NEW_MEMBER",
                        title = "New Member",
                        description = "Successfully created and verified your Pro Invest account.",
                        iconName = "Star",
                        xpReward = 50,
                        isUnlocked = true,
                        unlockedAt = now - (14L * 86400000L)
                    ),
                    AchievementEntity(
                        id = 2,
                        code = "FIRST_DEPOSIT",
                        title = "First Deposit",
                        description = "Completed your first secure wallet deposit transaction.",
                        iconName = "AccountBalanceWallet",
                        xpReward = 100,
                        isUnlocked = true,
                        unlockedAt = now - (14L * 86400000L)
                    ),
                    AchievementEntity(
                        id = 3,
                        code = "SMART_INVESTOR",
                        title = "Smart Investor",
                        description = "Subscribed to a verified investment plan.",
                        iconName = "TrendingUp",
                        xpReward = 150,
                        isUnlocked = true,
                        unlockedAt = now - (12L * 86400000L)
                    ),
                    AchievementEntity(
                        id = 4,
                        code = "SEVEN_DAY_STREAK",
                        title = "7-Day Streak",
                        description = "Logged in and checked in for seven consecutive days.",
                        iconName = "Whatshot",
                        xpReward = 200,
                        isUnlocked = false
                    ),
                    AchievementEntity(
                        id = 5,
                        code = "SECURITY_CHAMPION",
                        title = "Security Champion",
                        description = "Completed security checklist and device verification.",
                        iconName = "Shield",
                        xpReward = 100,
                        isUnlocked = true,
                        unlockedAt = now - (10L * 86400000L)
                    ),
                    AchievementEntity(
                        id = 6,
                        code = "SPIN_MASTER",
                        title = "Spin Master",
                        description = "Spun the lucky wheel of rewards 5 times.",
                        iconName = "Casino",
                        xpReward = 80,
                        isUnlocked = false
                    ),
                    AchievementEntity(
                        id = 7,
                        code = "REFERRAL_PRO",
                        title = "Referral Pro",
                        description = "Invited 3 friends who verified their accounts.",
                        iconName = "GroupAdd",
                        xpReward = 250,
                        isUnlocked = false
                    )
                )
            )

            // Seed Banners
            db.bannerDao().insertAll(
                listOf(
                    BannerEntity(
                        id = 1,
                        title = "Green Energy Horizon Fund",
                        subtitle = "Earn 10% - 13.5% est. yield with clean infrastructure",
                        tag = "FEATURED PLAN",
                        actionRoute = "plans"
                    ),
                    BannerEntity(
                        id = 2,
                        title = "Daily Spin & Fortune Wheel",
                        subtitle = "Free daily spins with guaranteed XP & points",
                        tag = "REWARDS",
                        actionRoute = "spin"
                    ),
                    BannerEntity(
                        id = 3,
                        title = "Invite & Grow Together",
                        subtitle = "Earn 500 Loyalty Points for each verified referral",
                        tag = "COMMUNITY",
                        actionRoute = "referral"
                    )
                )
            )

            // Seed Notifications
            db.notificationDao().insert(
                NotificationEntity(
                    userId = 1,
                    title = "Deposit Confirmed",
                    message = "Your deposit of ৳40,000 via bKash has been verified and added to your balance.",
                    category = "FINANCIAL",
                    timestamp = now - (14L * 86400000L),
                    isRead = true
                )
            )
            db.notificationDao().insert(
                NotificationEntity(
                    userId = 1,
                    title = "Daily Spin Available",
                    message = "Your free daily wheel spin is ready. Try your luck today!",
                    category = "SPIN",
                    timestamp = now - 3600000L,
                    isRead = false
                )
            )
            db.notificationDao().insert(
                NotificationEntity(
                    userId = 1,
                    title = "Weekly Challenge Completed",
                    message = "You finished 'Education Enthusiast'. Claim your rewards in the Mission Center!",
                    category = "MISSION",
                    timestamp = now - 1800000L,
                    isRead = false
                )
            )

            // Seed Audit Log
            db.auditDao().insert(
                AuditLogEntity(
                    actor = "SYSTEM",
                    action = "INITIALIZE",
                    details = "Platform initialized with secure financial ledger and seed plans."
                )
            )
        }
    }
}
