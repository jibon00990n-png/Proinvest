package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SupportTicketEntity
import com.example.ui.components.CategoryFilterChip
import com.example.ui.components.ProHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProInvestViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SupportScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val tickets by viewModel.userTickets.collectAsState()

    var subject by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("DEPOSIT") }
    var message by remember { mutableStateOf("") }
    var showCreateTicket by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            ProHeader(
                title = "Help & Customer Support",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("support_screen_scroll"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // FAQs Section
            item {
                Text("Frequently Asked Questions", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                FaqAccordion(
                    question = "How are daily investment yields calculated?",
                    answer = "Yields are calculated pro-rata daily based on real portfolio asset deployment (money market notes, green infrastructure, or sovereign securities). Daily returns are credited to your Available Balance."
                )
                Spacer(modifier = Modifier.height(8.dp))
                FaqAccordion(
                    question = "How long do bKash and Nagad deposits take?",
                    answer = "Once you submit your transaction ID (TrxID) and sender number, our clearing settlement team verifies the reference within 5 to 30 minutes during standard clearing hours."
                )
                Spacer(modifier = Modifier.height(8.dp))
                FaqAccordion(
                    question = "Can promotional credits be withdrawn as cash?",
                    answer = "No. Promotional credits and loyalty points are platform engagement rewards. They can be used to subsidize investment plan entries or redeem perks, but cannot be withdrawn directly."
                )
                Spacer(modifier = Modifier.height(8.dp))
                FaqAccordion(
                    question = "How does the Daily Spin wheel work?",
                    answer = "All verified users receive 1 free daily spin resetting at midnight. Rewards (XP, Loyalty Points, Promo Credits, Cash) are determined using configured transparent probability algorithms."
                )
            }

            // Ticket Submission CTA
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Your Support Tickets (${tickets.size})", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Button(
                        onClick = { showCreateTicket = !showCreateTicket },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (showCreateTicket) "Close Form" else "New Ticket", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // New Ticket Form
            if (showCreateTicket) {
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Open a Support Ticket", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = subject,
                                onValueChange = { subject = it },
                                label = { Text("Subject / Issue Summary") },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            // Category Selector
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                CategoryFilterChip("Deposit", category == "DEPOSIT") { category = "DEPOSIT" }
                                CategoryFilterChip("Withdrawal", category == "WITHDRAWAL") { category = "WITHDRAWAL" }
                                CategoryFilterChip("Plan", category == "INVESTMENT") { category = "INVESTMENT" }
                                CategoryFilterChip("Other", category == "OTHER") { category = "OTHER" }
                            }
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = message,
                                onValueChange = { message = it },
                                label = { Text("Describe your query or issue in detail") },
                                minLines = 3,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    if (subject.isBlank() || message.isBlank()) {
                                        viewModel.showMessage("Please fill subject and description", isError = true)
                                    } else {
                                        viewModel.submitTicket(subject, category, message)
                                        subject = ""
                                        message = ""
                                        showCreateTicket = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Submit Ticket", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Ticket List
            if (tickets.isEmpty()) {
                item {
                    Text("No tickets opened yet.", fontSize = 12.sp, color = SlateTextMuted)
                }
            } else {
                items(tickets) { ticket ->
                    TicketCard(ticket = ticket)
                }
            }
        }
    }
}

@Composable
fun FaqAccordion(question: String, answer: String) {
    var expanded by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    question,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = SlateTextMuted
                )
            }
            if (expanded) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    answer,
                    fontSize = 12.sp,
                    color = SlateTextSecondary,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
fun TicketCard(ticket: SupportTicketEntity) {
    val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.US)
    val dateStr = dateFormat.format(Date(ticket.createdAt))

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(ticket.subject, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                StatusPill(status = ticket.status)
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text("Category: ${ticket.category} • Submitted: $dateStr", fontSize = 11.sp, color = SlateTextSecondary)
            Spacer(modifier = Modifier.height(6.dp))
            Text(ticket.message, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)

            if (!ticket.adminResponse.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = ElectricBlueSoft.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Official Support Response:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ElectricBlue)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(ticket.adminResponse, fontSize = 11.sp, color = SlateTextPrimary)
                    }
                }
            }
        }
    }
}

@Composable
fun RiskDisclosureScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()

    Scaffold(
        topBar = {
            ProHeader(
                title = "Investment Risk Disclosure",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("1. No Guaranteed Returns", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "All estimated returns shown on PRO INVEST represent projections based on historical asset yield and portfolio allocations. PRO INVEST does not guarantee returns on any investment plans.",
                            fontSize = 12.sp,
                            color = SlateTextSecondary,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Text("2. Capital Risk", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Investing in financial instruments, commercial papers, and growth infrastructure involves risk of capital loss. Users must assess their own financial situation and risk appetite before deploying funds.",
                            fontSize = 12.sp,
                            color = SlateTextSecondary,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Text("3. Distinction of Funds", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Available cash balances represent withdrawable user funds. Promotional credits and loyalty points are non-withdrawable promotional incentives governed by platform campaign terms.",
                            fontSize = 12.sp,
                            color = SlateTextSecondary,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Text("4. Regulatory & AML Compliance", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "All users must comply with Know Your Customer (KYC) requirements. Transactions are recorded in an immutable ledger and monitored to prevent fraud, money laundering, and unauthorized access.",
                            fontSize = 12.sp,
                            color = SlateTextSecondary,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TermsScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()

    Scaffold(
        topBar = {
            ProHeader(
                title = "Terms & Conditions",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Terms of Service", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "By accessing or using the PRO INVEST platform, you agree to be bound by these Terms of Service. Users must be at least 18 years of age. Each user is permitted exactly one registered account. Multi-accounting, referral fraud, or automated script manipulation is strictly prohibited and subject to account restriction.",
                            fontSize = 12.sp,
                            color = SlateTextSecondary,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PrivacyScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()

    Scaffold(
        topBar = {
            ProHeader(
                title = "Privacy Policy",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Privacy Policy & Data Protection", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "We value your privacy. We collect personal identification info (name, email, phone number) strictly for account security, KYC verification, and transaction processing. We do not sell user data to third parties. All financial data is encrypted and handled under stringent security protocols.",
                            fontSize = 12.sp,
                            color = SlateTextSecondary,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}
