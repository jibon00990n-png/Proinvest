package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.example.data.repository.ProInvestRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class Screen {
    HOME,
    PLANS,
    MY_INVESTMENTS,
    DEPOSIT,
    WITHDRAW,
    MISSIONS,
    CHECK_IN,
    SPIN_WHEEL,
    REFERRAL,
    ACHIEVEMENTS,
    CHALLENGES,
    LOYALTY,
    TRANSACTIONS,
    NOTIFICATIONS,
    PROFILE,
    SUPPORT,
    RISK_DISCLOSURE,
    TERMS,
    PRIVACY,
    ADMIN_PANEL,
    AUTH
}

data class UiMessage(
    val message: String,
    val isError: Boolean = false,
    val id: Long = System.currentTimeMillis()
)

class ProInvestViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val repository = ProInvestRepository(db)

    // Current User Session
    private val _isLoading = MutableStateFlow(false)
    val isLoading = _isLoading.asStateFlow()

    private val _currentUserId = MutableStateFlow<Long>(1L)
    val currentUserId = _currentUserId.asStateFlow()

    // Screen State
    private val _currentScreen = MutableStateFlow(Screen.HOME)
    val currentScreen = _currentScreen.asStateFlow()

    // Navigation Stack for seamless back handling
    private val backStack = mutableListOf<Screen>()

    // Message Banner
    private val _uiMessage = MutableStateFlow<UiMessage?>(null)
    val uiMessage = _uiMessage.asStateFlow()

    // Data Flows
    val currentUser: StateFlow<UserEntity?> = _currentUserId
        .flatMapLatest { id -> repository.getCurrentUser(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activePlans: StateFlow<List<InvestmentPlanEntity>> = repository.getActivePlans()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPlans: StateFlow<List<InvestmentPlanEntity>> = repository.getAllPlans()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userInvestments: StateFlow<List<InvestmentEntity>> = _currentUserId
        .flatMapLatest { id -> repository.getInvestmentsForUser(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userTransactions: StateFlow<List<TransactionEntity>> = _currentUserId
        .flatMapLatest { id -> repository.getTransactionsForUser(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTransactions: StateFlow<List<TransactionEntity>> = repository.getAllTransactions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allUsers: StateFlow<List<UserEntity>> = repository.getAllUsers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val missions: StateFlow<List<DailyMissionEntity>> = repository.getAllMissions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val challenges: StateFlow<List<WeeklyChallengeEntity>> = repository.getAllChallenges()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val achievements: StateFlow<List<AchievementEntity>> = repository.getAllAchievements()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = _currentUserId
        .flatMapLatest { id -> repository.getNotificationsForUser(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userTickets: StateFlow<List<SupportTicketEntity>> = _currentUserId
        .flatMapLatest { id -> repository.getTicketsForUser(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTickets: StateFlow<List<SupportTicketEntity>> = repository.getAllTickets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val banners: StateFlow<List<BannerEntity>> = repository.getActiveBanners()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntity>> = repository.getAllAuditLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Spin Wheel State
    private val _isSpinning = MutableStateFlow(false)
    val isSpinning = _isSpinning.asStateFlow()

    private val _lastSpinResult = MutableStateFlow<Pair<String, Double>?>(null)
    val lastSpinResult = _lastSpinResult.asStateFlow()

    init {
        // Ensure initial database seeds are triggered
        viewModelScope.launch {
            // Trigger pre-population if empty
            val user = db.userDao().getUserByIdDirect(1)
            if (user == null) {
                AppDatabase.populateInitialData(db)
            }
        }
    }

    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            backStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (backStack.isNotEmpty()) {
            _currentScreen.value = backStack.removeAt(backStack.size - 1)
            return true
        }
        if (_currentScreen.value != Screen.HOME) {
            _currentScreen.value = Screen.HOME
            return true
        }
        return false
    }

    fun clearMessage() {
        _uiMessage.value = null
    }

    fun showMessage(msg: String, isError: Boolean = false) {
        _uiMessage.value = UiMessage(msg, isError)
    }

    // Role Switcher for seamless testing of User & Admin
    fun switchUserRole(toAdmin: Boolean) {
        viewModelScope.launch {
            val targetId = if (toAdmin) 2L else 1L
            _currentUserId.value = targetId
            showMessage(if (toAdmin) "Switched to Administrator Account (ID: 2)" else "Switched to Investor Account (ID: 1)")
        }
    }

    // Auth Actions
    fun login(email: String, pass: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                kotlinx.coroutines.delay(450) // professional brief load feel
                val user = repository.login(email, pass)
                if (user != null) {
                    if (user.isAdmin) {
                        showMessage("This is the User app. Please use the PRO INVEST Admin app.", isError = true)
                        return@launch
                    }
                    _currentUserId.value = user.id
                    _currentScreen.value = Screen.HOME
                    showMessage("Welcome back, ${user.fullName}!")
                } else {
                    showMessage("Invalid credentials. Try: user@proinvest.com / pass123", isError = true)
                }
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun register(fullName: String, email: String, phone: String, pass: String, refCode: String?) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                kotlinx.coroutines.delay(500)
                val result = repository.registerUser(fullName, email, phone, pass, refCode)
                result.onSuccess { user ->
                    _currentUserId.value = user.id
                    _currentScreen.value = Screen.HOME
                    showMessage("Account created successfully with ৳5,000 welcome demo balance!")
                }.onFailure { err ->
                    showMessage(err.message ?: "Registration failed", isError = true)
                }
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun logout() {
        _currentScreen.value = Screen.AUTH
        showMessage("Logged out successfully.")
    }

    // Investment Actions
    fun invest(planId: Long, amount: Double) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                kotlinx.coroutines.delay(400)
                val result = repository.subscribeToPlan(_currentUserId.value, planId, amount)
                result.onSuccess {
                    showMessage("Successfully invested ৳${amount.toInt()}! Yield calculation started.")
                    navigateTo(Screen.MY_INVESTMENTS)
                }.onFailure { err ->
                    showMessage(err.message ?: "Investment failed", isError = true)
                }
            } finally {
                _isLoading.value = false
            }
        }
    }

    // Deposit Actions
    fun requestDeposit(amount: Double, method: String, senderNumber: String, txId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                kotlinx.coroutines.delay(450)
                val result = repository.createDepositRequest(_currentUserId.value, amount, method, senderNumber, txId)
                result.onSuccess {
                    showMessage("Deposit request submitted! Status: PENDING review by admin agent.")
                    navigateTo(Screen.TRANSACTIONS)
                }.onFailure { err ->
                    showMessage(err.message ?: "Deposit request failed", isError = true)
                }
            } finally {
                _isLoading.value = false
            }
        }
    }

    // Withdrawal Actions
    fun requestWithdrawal(amount: Double, method: String, accountHolder: String, accountNumber: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                kotlinx.coroutines.delay(450)
                val result = repository.createWithdrawalRequest(_currentUserId.value, amount, method, accountHolder, accountNumber)
                result.onSuccess {
                    showMessage("Withdrawal submitted! Funds reserved in pending escrow.")
                    navigateTo(Screen.TRANSACTIONS)
                }.onFailure { err ->
                    showMessage(err.message ?: "Withdrawal request failed", isError = true)
                }
            } finally {
                _isLoading.value = false
            }
        }
    }

    // Daily Check-in
    fun checkInToday() {
        viewModelScope.launch {
            val result = repository.performDailyCheckIn(_currentUserId.value)
            result.onSuccess { streak ->
                showMessage("Checked in! You're on a $streak-day streak.")
            }.onFailure { err ->
                showMessage(err.message ?: "Check-in failed", isError = true)
            }
        }
    }

    // Daily Spin
    fun spinWheel() {
        viewModelScope.launch {
            if (_isSpinning.value) return@launch
            _isSpinning.value = true
            val result = repository.executeDailySpin(_currentUserId.value)
            result.onSuccess { prize ->
                _lastSpinResult.value = prize
                _isSpinning.value = false
                showMessage("Congratulations! You won ${prize.first}!")
            }.onFailure { err ->
                _isSpinning.value = false
                showMessage(err.message ?: "Spin failed", isError = true)
            }
        }
    }

    fun dismissSpinResult() {
        _lastSpinResult.value = null
    }

    // Daily Mission
    fun claimMission(missionId: Long) {
        viewModelScope.launch {
            val result = repository.claimMissionReward(_currentUserId.value, missionId)
            result.onSuccess {
                showMessage("Reward claimed successfully!")
            }.onFailure { err ->
                showMessage(err.message ?: "Claim failed", isError = true)
            }
        }
    }

    fun completeMissionActivity(missionId: Long) {
        viewModelScope.launch {
            val result = repository.completeMission(missionId)
            result.onSuccess {
                showMessage("Mission activity completed! Ready to claim reward.")
            }.onFailure { err ->
                showMessage(err.message ?: "Failed", isError = true)
            }
        }
    }

    // Weekly Challenge Claim
    fun claimChallenge(challengeId: Long) {
        viewModelScope.launch {
            val result = repository.claimChallengeReward(_currentUserId.value, challengeId)
            result.onSuccess {
                showMessage("Weekly Challenge Reward claimed!")
            }.onFailure { err ->
                showMessage(err.message ?: "Claim failed", isError = true)
            }
        }
    }

    // Mystery Box
    fun openMysteryBox() {
        viewModelScope.launch {
            val result = repository.openMysteryBox(_currentUserId.value)
            result.onSuccess { prize ->
                showMessage("Mystery Box Opened! Unlocked: $prize")
            }.onFailure { err ->
                showMessage(err.message ?: "Failed to open box", isError = true)
            }
        }
    }

    // Loyalty Points Store
    fun redeemLoyalty(title: String, cost: Int, perkType: String) {
        viewModelScope.launch {
            val result = repository.redeemLoyaltyReward(_currentUserId.value, title, cost, perkType)
            result.onSuccess {
                showMessage("Redeemed '$title' for $cost points!")
            }.onFailure { err ->
                showMessage(err.message ?: "Redemption failed", isError = true)
            }
        }
    }

    // Support Ticket
    fun submitTicket(subject: String, category: String, message: String) {
        viewModelScope.launch {
            val email = currentUser.value?.email ?: "user@proinvest.com"
            val result = repository.submitSupportTicket(_currentUserId.value, email, subject, category, message)
            result.onSuccess {
                showMessage("Support ticket #${it.id} submitted! Our team will respond shortly.")
            }.onFailure { err ->
                showMessage(err.message ?: "Failed to submit ticket", isError = true)
            }
        }
    }

    // Admin Controls
    fun adminApproveTx(txId: Long) {
        viewModelScope.launch {
            val actor = currentUser.value?.fullName ?: "Admin"
            val result = repository.approveTransaction(txId, actor)
            result.onSuccess {
                showMessage("Transaction #$txId approved successfully!")
            }.onFailure { err ->
                showMessage(err.message ?: "Approval failed", isError = true)
            }
        }
    }

    fun adminRejectTx(txId: Long, reason: String) {
        viewModelScope.launch {
            val actor = currentUser.value?.fullName ?: "Admin"
            val result = repository.rejectTransaction(txId, reason, actor)
            result.onSuccess {
                showMessage("Transaction #$txId rejected and balance reconciled.")
            }.onFailure { err ->
                showMessage(err.message ?: "Rejection failed", isError = true)
            }
        }
    }

    fun adminToggleKyc(userId: Long, isVerified: Boolean) {
        viewModelScope.launch {
            repository.toggleKycVerification(userId, isVerified)
            showMessage("User #$userId KYC status updated to ${if (isVerified) "VERIFIED" else "PENDING"}")
        }
    }

    fun adminAnswerTicket(ticketId: Long, response: String) {
        viewModelScope.launch {
            val result = repository.answerSupportTicket(ticketId, response)
            result.onSuccess {
                showMessage("Response sent to user for ticket #$ticketId")
            }
        }
    }

    fun adminSavePlan(plan: InvestmentPlanEntity) {
        viewModelScope.launch {
            repository.addOrUpdatePlan(plan, currentUser.value?.email ?: "Admin")
            showMessage("Investment plan '${plan.name}' saved successfully!")
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead(_currentUserId.value)
            showMessage("All notifications marked as read.")
        }
    }
}
