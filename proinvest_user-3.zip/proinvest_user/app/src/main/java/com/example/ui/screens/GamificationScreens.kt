package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProInvestViewModel
import com.example.ui.viewmodel.Screen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DailyMissionScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val missions by viewModel.missions.collectAsState()

    var activeMissionModal by remember { mutableStateOf<DailyMissionEntity?>(null) }

    Scaffold(
        topBar = {
            ProHeader(
                title = "Daily Mission Center",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("daily_missions_scroll"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Missions Progress Header
            item {
                val completedCount = missions.count { it.isCompleted }
                val claimedCount = missions.count { it.isClaimed }
                val totalCount = missions.size.coerceAtLeast(1)

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Brush.horizontalGradient(listOf(NavyDark, NavyCard)))
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Today's Missions", fontSize = 12.sp, color = SlateTextMuted)
                                Text(
                                    "$completedCount of $totalCount Completed",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = AmberGoldLight
                            ) {
                                Text(
                                    "$claimedCount Claimed",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AmberGoldDark,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        LinearProgressIndicator(
                            progress = { completedCount.toFloat() / totalCount.toFloat() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = EmeraldSuccess,
                            trackColor = Color(0xFF202F48)
                        )
                    }
                }
            }

            // Mission list items
            items(missions) { mission ->
                MissionRow(
                    mission = mission,
                    onClaim = { viewModel.claimMission(mission.id) },
                    onStart = {
                        activeMissionModal = mission
                    }
                )
            }
        }
    }

    // Modal for completing genuine mission activity
    activeMissionModal?.let { mission ->
        MissionActivityDialog(
            mission = mission,
            onDismiss = { activeMissionModal = null },
            onVerified = {
                viewModel.completeMissionActivity(mission.id)
                activeMissionModal = null
            }
        )
    }
}

@Composable
fun MissionActivityDialog(
    mission: DailyMissionEntity,
    onDismiss: () -> Unit,
    onVerified: () -> Unit
) {
    var selectedOption by remember { mutableStateOf<Int?>(null) }
    var quizError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(mission.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                when (mission.missionType) {
                    "QUIZ" -> {
                        Text(
                            "Question: " + mission.details,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        val options = listOf(
                            "Calculating the approximate years required to double your investment at a fixed rate.",
                            "Determining income tax rates for senior citizens.",
                            "Measuring foreign currency exchange fluctuations."
                        )

                        options.forEachIndexed { index, option ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (selectedOption == index) ElectricBlueSoft else MaterialTheme.colorScheme.surfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (selectedOption == index) ElectricBlue else Color.Transparent
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedOption = index
                                        quizError = false
                                    }
                                    .padding(vertical = 4.dp)
                            ) {
                                Text(
                                    option,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }

                        if (quizError) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "Incorrect option. Read the financial tip or choose the correct rule of thumb!",
                                color = RoseError,
                                fontSize = 11.sp
                            )
                        }
                    }
                    "TIP" -> {
                        Text(
                            mission.details,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 18.sp
                        )
                    }
                    "SECURITY" -> {
                        Text(
                            "Security Hygiene Checklist:\n\n• Never give your password or 2FA OTP to third parties.\n• Verify URL and SSL certificate when logging in.\n• Use a unique, strong password.",
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                    else -> {
                        Text(
                            mission.details.ifBlank { "Viewed today's update successfully." },
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (mission.missionType == "QUIZ") {
                        if (selectedOption == 0) {
                            onVerified()
                        } else {
                            quizError = true
                        }
                    } else {
                        onVerified()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Complete & Verify", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = SlateTextSecondary)
            }
        }
    )
}

@Composable
fun DailyCheckInScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    val checkedToday = currentUser?.lastCheckInDate == todayStr

    Scaffold(
        topBar = {
            ProHeader(
                title = "Daily Check-in & Streak",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("check_in_scroll"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Streak Hero Card
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(NavyDark, Color(0xFF1F2937))
                                )
                            )
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEA580C)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Whatshot,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            "${currentUser?.streakDays ?: 0}-Day Streak",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            "Check in consecutively to multiply your XP & loyalty rewards!",
                            fontSize = 12.sp,
                            color = SlateTextMuted,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { viewModel.checkInToday() },
                            enabled = !checkedToday,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (checkedToday) EmeraldSuccess else Color(0xFFEA580C)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth(0.7f)
                                .height(46.dp)
                        ) {
                            Icon(
                                if (checkedToday) Icons.Default.Check else Icons.Default.TouchApp,
                                contentDescription = null,
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                if (checkedToday) "Checked in for Today" else "Check In Now",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // 7-Day Calendar Grid
            item {
                Text(
                    "7-Day Milestone Calendar",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val days = (currentUser?.streakDays ?: 0)
                    for (day in 1..7) {
                        val isDayDone = day <= (days % 7).let { if (it == 0 && days > 0) 7 else it }
                        DayStreakItem(
                            dayNumber = day,
                            isDone = isDayDone,
                            reward = if (day == 7) "+200 XP" else "+${30 + day * 5} XP",
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DayStreakItem(
    dayNumber: Int,
    isDone: Boolean,
    reward: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isDone) EmeraldSuccessLight else MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isDone) EmeraldSuccess else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
        ),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Day $dayNumber",
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (isDone) EmeraldSuccess else SlateTextSecondary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Icon(
                if (isDone) Icons.Default.CheckCircle else Icons.Default.Schedule,
                contentDescription = null,
                tint = if (isDone) EmeraldSuccess else SlateTextMuted,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                reward,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = if (isDone) EmeraldSuccess else SlateTextSecondary
            )
        }
    }
}

@Composable
fun SpinRewardsScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val isSpinning by viewModel.isSpinning.collectAsState()
    val lastResult by viewModel.lastSpinResult.collectAsState()

    Scaffold(
        topBar = {
            ProHeader(
                title = "Lucky Wheel & Spin",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("spin_screen_scroll"),
            contentPadding = PaddingValues(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                SpinWheelView(
                    isSpinning = isSpinning,
                    spinsAvailable = currentUser?.spinsAvailableToday ?: 0,
                    onSpinClick = { viewModel.spinWheel() }
                )
            }
        }
    }

    // Win dialog
    lastResult?.let { result ->
        AlertDialog(
            onDismissRequest = { viewModel.dismissSpinResult() },
            title = {
                Text("Congratulations!", fontWeight = FontWeight.Bold, color = EmeraldSuccess)
            },
            text = {
                Text(
                    "You won ${result.first}! The reward has been credited directly to your balance/account.",
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.dismissSpinResult() },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                ) {
                    Text("Collect", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun AchievementsScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val achievements by viewModel.achievements.collectAsState()
    val challenges by viewModel.challenges.collectAsState()

    Scaffold(
        topBar = {
            ProHeader(
                title = "Badges & Challenges",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("achievements_scroll"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Level Perks Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Brush.horizontalGradient(listOf(NavyDark, NavyCard)))
                            .padding(16.dp)
                    ) {
                        Text("Current Tier: Level ${currentUser?.level ?: 1}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AmberGold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Tier perks include: Priority withdrawal processing, 20% bonus daily spin odds, and exclusive access to high-yield sovereign investment plans.",
                            fontSize = 11.sp,
                            color = SlateTextMuted,
                            lineHeight = 15.sp
                        )
                    }
                }
            }

            // Weekly Challenges
            item {
                Text("Active Weekly Challenges", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }

            items(challenges) { ch ->
                WeeklyChallengeCard(
                    challenge = ch,
                    onClaim = { viewModel.claimChallenge(ch.id) }
                )
            }

            // Badges
            item {
                Text("Achievement Badges (${achievements.count { it.isUnlocked }} Unlocked)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }

            items(achievements) { badge ->
                BadgeRow(badge = badge)
            }
        }
    }
}

@Composable
fun WeeklyChallengeCard(
    challenge: WeeklyChallengeEntity,
    onClaim: () -> Unit
) {
    val progress = (challenge.currentCount.toFloat() / challenge.targetCount.toFloat()).coerceIn(0f, 1f)

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(challenge.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(challenge.description, fontSize = 11.sp, color = SlateTextSecondary)
                }

                if (challenge.isClaimed) {
                    Surface(shape = RoundedCornerShape(6.dp), color = EmeraldSuccessLight) {
                        Text("Claimed", color = EmeraldSuccess, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                } else if (challenge.currentCount >= challenge.targetCount || challenge.isCompleted) {
                    Button(
                        onClick = onClaim,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("Claim", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Progress: ${challenge.currentCount}/${challenge.targetCount}", fontSize = 10.sp, color = SlateTextSecondary)
                Text("Ends: ${challenge.endDateStr}", fontSize = 10.sp, color = SlateTextSecondary)
            }
            Spacer(modifier = Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = ElectricBlue,
                trackColor = SlateBorder
            )
        }
    }
}

@Composable
fun BadgeRow(badge: AchievementEntity) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(if (badge.isUnlocked) AmberGoldLight else SlateBorder),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Stars,
                    contentDescription = null,
                    tint = if (badge.isUnlocked) AmberGoldDark else SlateTextMuted,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    badge.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = if (badge.isUnlocked) MaterialTheme.colorScheme.onSurface else SlateTextMuted
                )
                Text(
                    badge.description,
                    fontSize = 11.sp,
                    color = SlateTextSecondary
                )
            }
            Text(
                "+${badge.xpReward} XP",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (badge.isUnlocked) ElectricBlue else SlateTextMuted
            )
        }
    }
}
