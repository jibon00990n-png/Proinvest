package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProInvestViewModel
import com.example.ui.viewmodel.Screen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val banners by viewModel.banners.collectAsState()
    val missions by viewModel.missions.collectAsState()
    val recentTx by viewModel.userTransactions.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }

    var showMysteryDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            ProHeader(
                title = "PRO INVEST",
                currentUser = currentUser,
                unreadNotifications = unreadCount,
                onNotificationClick = { viewModel.navigateTo(Screen.NOTIFICATIONS) },
                onProfileClick = { viewModel.navigateTo(Screen.PROFILE) }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("home_screen_scroll"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Multi-Wallet Balance Overview
            item {
                MultiBalanceCard(
                    user = currentUser,
                    onDepositClick = { viewModel.navigateTo(Screen.DEPOSIT) },
                    onWithdrawClick = { viewModel.navigateTo(Screen.WITHDRAW) }
                )
            }

            // XP Level & Streak Strip
            item {
                StreakAndXpCard(
                    user = currentUser,
                    onCheckInClick = { viewModel.checkInToday() },
                    onAchievementsClick = { viewModel.navigateTo(Screen.ACHIEVEMENTS) }
                )
            }

            // Quick Actions
            item {
                QuickActionGrid(
                    onPlansClick = { viewModel.navigateTo(Screen.PLANS) },
                    onMissionsClick = { viewModel.navigateTo(Screen.MISSIONS) },
                    onSpinClick = { viewModel.navigateTo(Screen.SPIN_WHEEL) },
                    onReferralClick = { viewModel.navigateTo(Screen.REFERRAL) },
                    onHistoryClick = { viewModel.navigateTo(Screen.TRANSACTIONS) },
                    onLoyaltyClick = { viewModel.navigateTo(Screen.LOYALTY) }
                )
            }

            // Promotional Banners Carousel
            if (banners.isNotEmpty()) {
                item {
                    Column {
                        Text(
                            "Featured Campaigns",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(banners) { banner ->
                                BannerItem(
                                    banner = banner,
                                    onClick = {
                                        when (banner.actionRoute) {
                                            "plans" -> viewModel.navigateTo(Screen.PLANS)
                                            "spin" -> viewModel.navigateTo(Screen.SPIN_WHEEL)
                                            "referral" -> viewModel.navigateTo(Screen.REFERRAL)
                                            else -> viewModel.navigateTo(Screen.PLANS)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Mystery Box Banner
            item {
                MysteryBoxBanner(
                    user = currentUser,
                    onOpenClick = { viewModel.openMysteryBox() }
                )
            }

            // Today's Missions Snapshot
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Daily Missions",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            "View All (${missions.size})",
                            color = ElectricBlue,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .clickable { viewModel.navigateTo(Screen.MISSIONS) }
                                .padding(4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    missions.take(3).forEach { mission ->
                        MissionRow(
                            mission = mission,
                            onClaim = { viewModel.claimMission(mission.id) },
                            onStart = {
                                if (!mission.isCompleted) {
                                    viewModel.completeMissionActivity(mission.id)
                                }
                            }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }

            // Recent Transactions Snapshot
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Recent Activity",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            "Ledger",
                            color = ElectricBlue,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .clickable { viewModel.navigateTo(Screen.TRANSACTIONS) }
                                .padding(4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (recentTx.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                "No transactions recorded yet.",
                                fontSize = 13.sp,
                                color = SlateTextMuted,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    } else {
                        recentTx.take(4).forEach { tx ->
                            TransactionRow(tx = tx)
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                }
            }

            // Compliance & Risk Transparency Notice
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = null,
                                tint = SlateTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "Financial Transparency & Risk Policy",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "All yields are calculated on verified portfolio allocation. Capital involves risk. Promotional credits cannot be withdrawn as cash. Never invest funds you cannot afford to risk.",
                            fontSize = 11.sp,
                            color = SlateTextSecondary,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StreakAndXpCard(
    user: UserEntity?,
    onCheckInClick: () -> Unit,
    onAchievementsClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        shadowElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Level & XP bar
            val currentXp = user?.xp ?: 0
            val nextLevelXp = (user?.level ?: 1) * 500
            val progress = (currentXp.toFloat() / nextLevelXp.toFloat()).coerceIn(0f, 1f)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(AmberGoldLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = AmberGoldDark,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            "Level ${user?.level ?: 1} Status",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            "$currentXp / $nextLevelXp XP to Level ${(user?.level ?: 1) + 1}",
                            fontSize = 11.sp,
                            color = SlateTextSecondary
                        )
                    }
                }

                Text(
                    "Badges >",
                    color = ElectricBlue,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onAchievementsClick() }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = ElectricBlue,
                trackColor = SlateBorder
            )

            Spacer(modifier = Modifier.height(14.dp))
            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(12.dp))

            // 7-Day Streak Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Whatshot,
                            contentDescription = null,
                            tint = Color(0xFFF97316),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "${user?.streakDays ?: 0}-Day Streak",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Text(
                        "Check in daily for bonuses",
                        fontSize = 11.sp,
                        color = SlateTextSecondary
                    )
                }

                val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                val checkedToday = user?.lastCheckInDate == todayStr

                Button(
                    onClick = onCheckInClick,
                    enabled = !checkedToday,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (checkedToday) EmeraldSuccess else Color(0xFFF97316)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(
                        if (checkedToday) Icons.Default.Check else Icons.Default.TouchApp,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        if (checkedToday) "Checked In" else "Check In",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun BannerItem(banner: BannerEntity, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = NavyDark,
        modifier = Modifier
            .width(260.dp)
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.linearGradient(
                        listOf(NavyDark, Color(0xFF1E3A8A))
                    )
                )
                .padding(14.dp)
        ) {
            Column {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = AmberGold
                ) {
                    Text(
                        banner.tag,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = NavyDark,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    banner.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    banner.subtitle,
                    fontSize = 11.sp,
                    color = SlateTextMuted,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 14.sp
                )
            }
        }
    }
}

@Composable
fun MysteryBoxBanner(user: UserEntity?, onOpenClick: () -> Unit) {
    val completed = user?.completedMissionsCount ?: 0
    val canOpen = completed >= 5 || user?.isAdmin == true

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (canOpen) Color(0xFF431407) else MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (canOpen) AmberGold else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (canOpen) AmberGold else SlateBorder),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.CardGiftcard,
                        contentDescription = "Mystery Box",
                        tint = if (canOpen) NavyDark else SlateTextMuted,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        "Mystery Reward Box",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (canOpen) AmberGoldLight else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        if (canOpen) "Unlocked! Tap to open." else "Complete 5 missions to unlock ($completed/5)",
                        fontSize = 11.sp,
                        color = if (canOpen) Color.White.copy(alpha = 0.8f) else SlateTextSecondary
                    )
                }
            }

            Button(
                onClick = onOpenClick,
                enabled = canOpen,
                colors = ButtonDefaults.buttonColors(
                    containerColor = AmberGold,
                    disabledContainerColor = SlateBorder
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    "Open",
                    color = if (canOpen) NavyDark else SlateTextMuted,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
fun MissionRow(
    mission: DailyMissionEntity,
    onClaim: () -> Unit,
    onStart: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            when (mission.rewardType) {
                                "XP" -> ElectricBlueSoft
                                "POINTS" -> EmeraldSuccessLight
                                else -> AmberGoldLight
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        when (mission.missionType) {
                            "CHECKIN" -> Icons.Default.CheckCircle
                            "QUIZ" -> Icons.Default.HelpOutline
                            "TIP" -> Icons.Default.Lightbulb
                            "SECURITY" -> Icons.Default.Security
                            else -> Icons.Default.Campaign
                        },
                        contentDescription = null,
                        tint = when (mission.rewardType) {
                            "XP" -> ElectricBlue
                            "POINTS" -> EmeraldSuccess
                            else -> AmberGoldDark
                        },
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        mission.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        "+${mission.rewardAmount} ${mission.rewardType} • ${mission.timeEstimate}",
                        fontSize = 11.sp,
                        color = SlateTextSecondary
                    )
                }
            }

            if (mission.isClaimed) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = EmeraldSuccessLight
                ) {
                    Text(
                        "Claimed",
                        color = EmeraldSuccess,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            } else if (mission.isCompleted) {
                Button(
                    onClick = onClaim,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text("Claim", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                OutlinedButton(
                    onClick = onStart,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ElectricBlue),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text("Start", fontSize = 11.sp, color = ElectricBlue, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

