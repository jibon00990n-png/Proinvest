package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Fintech Brand Palette — Professional & Trustworthy
val NavyDark = Color(0xFF0A0F1C)
val NavyPrimary = Color(0xFF0F172A)
val NavySurface = Color(0xFF1E293B)
val NavyCard = Color(0xFF162032)

val ElectricBlue = Color(0xFF1D4ED8)
val ElectricBlueLight = Color(0xFF3B82F6)
val ElectricBlueSoft = Color(0xFFEFF6FF)
val ElectricBlueMuted = Color(0xFFBFDBFE)

val EmeraldSuccess = Color(0xFF059669)
val EmeraldSuccessLight = Color(0xFFD1FAE5)
val EmeraldMuted = Color(0xFFA7F3D0)

val AmberGold = Color(0xFFD97706)
val AmberGoldDark = Color(0xFFB45309)
val AmberGoldLight = Color(0xFFFEF3C7)

val RoseError = Color(0xFFDC2626)
val RoseErrorLight = Color(0xFFFEE2E2)

val SlateBackground = Color(0xFFF8FAFC)
val SlateSurface = Color(0xFFFFFFFF)
val SlateBorder = Color(0xFFE2E8F0)
val SlateTextPrimary = Color(0xFF0F172A)
val SlateTextSecondary = Color(0xFF64748B)
val SlateTextMuted = Color(0xFF94A3B8)

// Dark Theme Variants — Deep professional dark
val DarkBackground = Color(0xFF060B14)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceElevated = Color(0xFF1E293B)
val DarkBorder = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)

// Gradients helpers
val GradientStart = Color(0xFF1E3A8A)
val GradientEnd = Color(0xFF3B82F6)
val GoldGradientStart = Color(0xFFF59E0B)
val GoldGradientEnd = Color(0xFFD97706)
