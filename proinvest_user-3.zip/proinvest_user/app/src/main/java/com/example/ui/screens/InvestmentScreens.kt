package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InvestmentEntity
import com.example.data.model.InvestmentPlanEntity
import com.example.ui.components.CategoryFilterChip
import com.example.ui.components.ProHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProInvestViewModel
import com.example.ui.viewmodel.Screen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun InvestmentPlansScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val plans by viewModel.activePlans.collectAsState()
    var selectedCategory by remember { mutableStateOf("ALL") }
    var planToInvest by remember { mutableStateOf<InvestmentPlanEntity?>(null) }

    val filteredPlans = remember(plans, selectedCategory) {
        if (selectedCategory == "ALL") plans else plans.filter { it.category == selectedCategory }
    }

    Scaffold(
        topBar = {
            ProHeader(
                title = "Investment Plans",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("investment_plans_scroll"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Portfolio & Balance Summary Banner
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Brush.horizontalGradient(listOf(NavyDark, NavyCard)))
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Available to Invest", fontSize = 12.sp, color = SlateTextMuted)
                            Text(
                                "৳" + String.format(Locale.US, "%,.2f", currentUser?.availableBalance ?: 0.0),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        Button(
                            onClick = { viewModel.navigateTo(Screen.MY_INVESTMENTS) },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("My Portfolio", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Category Filter Pills
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CategoryFilterChip("All Plans", selectedCategory == "ALL") { selectedCategory = "ALL" }
                    CategoryFilterChip("Starter", selectedCategory == "STARTER") { selectedCategory = "STARTER" }
                    CategoryFilterChip("Growth", selectedCategory == "GROWTH") { selectedCategory = "GROWTH" }
                    CategoryFilterChip("Premium", selectedCategory == "PREMIUM") { selectedCategory = "PREMIUM" }
                }
            }

            // Plan Cards
            items(filteredPlans) { plan ->
                PlanCard(
                    plan = plan,
                    onInvestClick = { planToInvest = plan }
                )
            }
        }
    }

    // Investment Subscription Dialog
    planToInvest?.let { plan ->
        InvestModalDialog(
            plan = plan,
            availableBalance = currentUser?.availableBalance ?: 0.0,
            onDismiss = { planToInvest = null },
            onConfirm = { amount ->
                viewModel.invest(plan.id, amount)
                planToInvest = null
            }
        )
    }
}

@Composable
fun PlanCard(
    plan: InvestmentPlanEntity,
    onInvestClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("plan_card_${plan.id}")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header with Risk Level
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        plan.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        plan.category + " Portfolio",
                        fontSize = 11.sp,
                        color = SlateTextSecondary
                    )
                }
                StatusPill(status = plan.riskLevel)
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                plan.description,
                fontSize = 12.sp,
                color = SlateTextSecondary,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Key Metrics Grid
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Est. Annual Yield", fontSize = 10.sp, color = SlateTextSecondary)
                    Text(
                        "${plan.estAnnualYieldMin}% - ${plan.estAnnualYieldMax}%",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = EmeraldSuccess
                    )
                }
                Column {
                    Text("Lock-in Period", fontSize = 10.sp, color = SlateTextSecondary)
                    Text(
                        "${plan.durationDays} Days",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Column {
                    Text("Min Capital", fontSize = 10.sp, color = SlateTextSecondary)
                    Text(
                        "৳" + String.format(Locale.US, "%,.0f", plan.minAmount),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Invest CTA Button
            Button(
                onClick = onInvestClick,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("invest_now_button_${plan.id}")
            ) {
                Icon(
                    Icons.Default.TrendingUp,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Invest in this Plan", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

@Composable
fun InvestModalDialog(
    plan: InvestmentPlanEntity,
    availableBalance: Double,
    onDismiss: () -> Unit,
    onConfirm: (Double) -> Unit
) {
    var amountText by remember { mutableStateOf(plan.minAmount.toInt().toString()) }
    var agreedRisk by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }

    val amount = amountText.toDoubleOrNull() ?: 0.0
    val estDailyYield = (amount * ((plan.estAnnualYieldMin + plan.estAnnualYieldMax) / 2.0 / 100.0)) / 365.0
    val estTotalYield = estDailyYield * plan.durationDays

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Subscribe: ${plan.name}",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Enter the capital you wish to allocate. Returns are calculated pro-rata daily based on real portfolio yield.",
                    fontSize = 12.sp,
                    color = SlateTextSecondary
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        errorText = null
                    },
                    label = { Text("Investment Amount (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = errorText != null,
                    supportingText = {
                        if (errorText != null) {
                            Text(errorText!!, color = RoseError, fontSize = 11.sp)
                        } else {
                            Text(
                                "Min: ৳${plan.minAmount.toInt()} • Max: ৳${plan.maxAmount.toInt()}",
                                fontSize = 11.sp,
                                color = SlateTextSecondary
                            )
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("invest_amount_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Calculator Preview Box
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = ElectricBlueSoft.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Est. Daily Yield:", fontSize = 11.sp, color = NavyPrimary)
                            Text("~৳" + String.format(Locale.US, "%,.2f", estDailyYield), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Est. Total at Maturity (${plan.durationDays}d):", fontSize = 11.sp, color = NavyPrimary)
                            Text("~৳" + String.format(Locale.US, "%,.2f", amount + estTotalYield), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NavyPrimary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Available Balance Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Your Available Balance:", fontSize = 11.sp, color = SlateTextSecondary)
                    Text("৳" + String.format(Locale.US, "%,.2f", availableBalance), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Terms & Risk Checkbox
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { agreedRisk = !agreedRisk }
                ) {
                    Checkbox(
                        checked = agreedRisk,
                        onCheckedChange = { agreedRisk = it },
                        colors = CheckboxDefaults.colors(checkedColor = ElectricBlue)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        "I understand that investment involves risk and past performance is not a guarantee.",
                        fontSize = 10.sp,
                        color = SlateTextSecondary,
                        lineHeight = 13.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (amount < plan.minAmount) {
                        errorText = "Minimum investment is ৳${plan.minAmount.toInt()}"
                    } else if (amount > plan.maxAmount) {
                        errorText = "Maximum investment is ৳${plan.maxAmount.toInt()}"
                    } else if (amount > availableBalance) {
                        errorText = "Insufficient available balance. Deposit funds first."
                    } else if (!agreedRisk) {
                        errorText = "Please agree to the risk disclosure."
                    } else {
                        onConfirm(amount)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("confirm_invest_button")
            ) {
                Text("Confirm Investment", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SlateTextSecondary)
            }
        }
    )
}

@Composable
fun MyInvestmentsScreen(viewModel: ProInvestViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val investments by viewModel.userInvestments.collectAsState()

    val totalActiveInvested = remember(investments) {
        investments.filter { it.status == "ACTIVE" }.sumOf { it.investedAmount }
    }
    val totalAccruedYield = remember(investments) {
        investments.sumOf { it.accruedProfit }
    }

    Scaffold(
        topBar = {
            ProHeader(
                title = "My Portfolio",
                currentUser = currentUser,
                showBack = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("my_investments_scroll"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Portfolio Summary Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(NavyDark, NavyCard)))
                            .padding(18.dp)
                    ) {
                        Text("Active Capital Deployed", fontSize = 12.sp, color = SlateTextMuted)
                        Text(
                            "৳" + String.format(Locale.US, "%,.2f", totalActiveInvested),
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF0F1A30))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Total Accrued Yield", fontSize = 11.sp, color = SlateTextMuted)
                                Text(
                                    "+৳" + String.format(Locale.US, "%,.2f", totalAccruedYield),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldSuccess
                                )
                            }
                            Column {
                                Text("Active Holdings", fontSize = 11.sp, color = SlateTextMuted)
                                Text(
                                    "${investments.count { it.status == "ACTIVE" }} Plans",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Active Subscriptions (${investments.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Button(
                        onClick = { viewModel.navigateTo(Screen.PLANS) },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Explore More", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (investments.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.TrendingUp,
                                contentDescription = null,
                                tint = SlateTextMuted,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "No Active Investments",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Subscribe to a plan to start earning daily audited yields.",
                                fontSize = 12.sp,
                                color = SlateTextSecondary,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(investments) { inv ->
                    ActiveInvestmentCard(inv = inv)
                }
            }
        }
    }
}

@Composable
fun ActiveInvestmentCard(inv: InvestmentEntity) {
    val now = System.currentTimeMillis()
    val totalTime = (inv.maturityDate - inv.startDate).coerceAtLeast(1L)
    val elapsed = (now - inv.startDate).coerceAtLeast(0L)
    val progress = (elapsed.toFloat() / totalTime.toFloat()).coerceIn(0f, 1f)

    val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.US)
    val startStr = dateFormat.format(Date(inv.startDate))
    val endStr = dateFormat.format(Date(inv.maturityDate))

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        inv.planName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        "${inv.durationDays} Days Tenure • Started $startStr",
                        fontSize = 11.sp,
                        color = SlateTextSecondary
                    )
                }
                StatusPill(status = inv.status)
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Invested Capital", fontSize = 11.sp, color = SlateTextSecondary)
                    Text(
                        "৳" + String.format(Locale.US, "%,.2f", inv.investedAmount),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("Accrued Return", fontSize = 11.sp, color = SlateTextSecondary)
                    Text(
                        "+৳" + String.format(Locale.US, "%,.2f", inv.accruedProfit),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldSuccess
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Maturity Progress Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Tenure Progress", fontSize = 10.sp, color = SlateTextSecondary)
                Text("Matures on $endStr", fontSize = 10.sp, color = SlateTextSecondary)
            }
            Spacer(modifier = Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = ElectricBlue,
                trackColor = SlateBorder
            )
        }
    }
}
