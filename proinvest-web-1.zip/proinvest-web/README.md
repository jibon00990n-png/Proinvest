# PRO INVEST — Web App

Professional multi-file fintech demo website (User + Admin).

## Structure
```
proinvest-web/
├── index.html              # Landing
├── login.html              # Investor login
├── register.html           # Register
├── css/
│   ├── main.css            # Design system
│   └── animations.css      # Transitions, shimmer, spin
├── js/
│   ├── data.js             # localStorage data layer
│   └── app.js              # UI helpers, auth guards
├── user/
│   ├── home.html
│   ├── plans.html
│   ├── deposit.html
│   ├── withdraw.html
│   ├── investments.html
│   ├── transactions.html
│   ├── missions.html
│   ├── spin.html
│   ├── profile.html
│   └── notifications.html
└── admin/
    ├── login.html
    └── dashboard.html
```

## Demo accounts
| Role  | Email                 | Password  |
|-------|-----------------------|-----------|
| User  | user@proinvest.com    | pass123   |
| Admin | admin@proinvest.com   | admin123  |

## Run locally
```bash
cd proinvest-web
npx --yes serve -p 3000
# or: python3 -m http.server 8080
```
Open http://localhost:3000

## Deploy
- **Netlify / Vercel / GitHub Pages**: drag the `proinvest-web` folder or connect the repo.
- No build step required (static HTML/CSS/JS).

## Features
- Investor: balances, plans, invest, deposit/withdraw (pending flow), missions, spin, profile
- Admin: metrics, approve/reject txs, KYC toggle, plan list
- Animations, loading overlay, toasts
- Data persists in browser localStorage

## Note
This is a **frontend demo**. Production would need a real backend (Firebase / API) instead of localStorage.
