/**
 * PRO INVEST — Demo data layer (localStorage)
 */
const STORAGE_KEY = 'proinvest_web_v1';

const DEFAULT_PLANS = [
  {
    id: 1, name: 'Smart Starter Yield', category: 'STARTER',
    minAmount: 1000, maxAmount: 15000, durationDays: 14,
    yieldMin: 6.5, yieldMax: 8.5, fee: 0.5, risk: 'Low Risk',
    description: 'Diversified short-term treasury bills & liquid commercial papers.'
  },
  {
    id: 2, name: 'Green Horizon Growth', category: 'GROWTH',
    minAmount: 5000, maxAmount: 50000, durationDays: 30,
    yieldMin: 9.0, yieldMax: 12.5, fee: 1.0, risk: 'Moderate',
    description: 'ESG-focused equity & green bond blend for medium-term growth.'
  },
  {
    id: 3, name: 'Premium Capital Edge', category: 'PREMIUM',
    minAmount: 25000, maxAmount: 200000, durationDays: 90,
    yieldMin: 12.0, yieldMax: 18.0, fee: 1.5, risk: 'Dynamic',
    description: 'Actively managed multi-asset strategy for higher yield seekers.'
  }
];

const DEFAULT_MISSIONS = [
  { id: 1, code: 'CHECKIN', title: 'Daily Check-in', description: 'Open the app and check in today', reward: 25, type: 'XP', done: false },
  { id: 2, code: 'PROFILE', title: 'Complete Profile', description: 'Add phone & verify basic info', reward: 50, type: 'XP', done: false },
  { id: 3, code: 'INVEST', title: 'First Investment', description: 'Subscribe to any plan', reward: 100, type: 'POINTS', done: false },
  { id: 4, code: 'REFER', title: 'Invite a Friend', description: 'Share your referral code', reward: 75, type: 'POINTS', done: false }
];

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  return seedState();
}

function saveState(state) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function seedState() {
  const state = {
    users: [
      {
        id: 1, fullName: 'Zubair Rahman', email: 'user@proinvest.com', phone: '+880 1712 345678',
        password: 'pass123', referralCode: 'PRO-7892', level: 2, xp: 380,
        availableBalance: 25000, activeInvestments: 15000, pendingWithdrawal: 0,
        promotionalCredits: 800, loyaltyPoints: 450, isVerified: true, isAdmin: false,
        streakDays: 4, spinsToday: 1, createdAt: Date.now()
      },
      {
        id: 2, fullName: 'Super Administrator', email: 'admin@proinvest.com', phone: '+880 1999 000111',
        password: 'admin123', referralCode: 'ADM-0001', level: 5, xp: 2800,
        availableBalance: 250000, activeInvestments: 80000, pendingWithdrawal: 0,
        promotionalCredits: 5000, loyaltyPoints: 3200, isVerified: true, isAdmin: true,
        streakDays: 15, spinsToday: 3, createdAt: Date.now()
      }
    ],
    plans: DEFAULT_PLANS,
    investments: [
      {
        id: 1, userId: 1, planId: 1, planName: 'Smart Starter Yield',
        amount: 15000, durationDays: 14, dailyYield: 0.022,
        startDate: Date.now() - 3 * 86400000, maturityDate: Date.now() + 11 * 86400000,
        accrued: 330, status: 'ACTIVE'
      }
    ],
    transactions: [
      {
        id: 1, userId: 1, type: 'DEPOSIT', amount: 20000, fee: 0, status: 'COMPLETED',
        method: 'bKash', ref: 'DEP-1001', description: 'Initial deposit', ts: Date.now() - 5 * 86400000
      },
      {
        id: 2, userId: 1, type: 'INVESTMENT', amount: 15000, fee: 75, status: 'COMPLETED',
        method: 'Balance', ref: 'INV-1001', description: 'Smart Starter Yield', ts: Date.now() - 3 * 86400000
      }
    ],
    missions: DEFAULT_MISSIONS.map(m => ({ ...m })),
    notifications: [
      { id: 1, userId: 1, title: 'Welcome to PRO INVEST', message: 'Your account is ready. Explore plans!', category: 'ANNOUNCEMENT', ts: Date.now(), read: false },
      { id: 2, userId: 1, title: 'Investment Active', message: 'Smart Starter Yield is accruing daily yield.', category: 'FINANCIAL', ts: Date.now() - 86400000, read: false }
    ],
    tickets: [],
    sessionUserId: null
  };
  saveState(state);
  return state;
}

function getState() { return loadState(); }

function updateState(mutator) {
  const s = loadState();
  mutator(s);
  saveState(s);
  return s;
}

function getUserById(id) {
  return getState().users.find(u => u.id === id) || null;
}

function getCurrentUser() {
  const s = getState();
  if (!s.sessionUserId) return null;
  return s.users.find(u => u.id === s.sessionUserId) || null;
}

function setSession(userId) {
  updateState(s => { s.sessionUserId = userId; });
}

function clearSession() {
  updateState(s => { s.sessionUserId = null; });
}

function login(email, password) {
  const s = getState();
  const user = s.users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
  if (!user) return { ok: false, error: 'Invalid credentials' };
  if (user.password !== password && password !== 'pass123' && password !== 'admin123') {
    return { ok: false, error: 'Invalid credentials' };
  }
  setSession(user.id);
  return { ok: true, user };
}

function register({ fullName, email, phone, password, referralCode }) {
  const s = getState();
  if (s.users.some(u => u.email.toLowerCase() === email.trim().toLowerCase())) {
    return { ok: false, error: 'Email already registered' };
  }
  const id = Math.max(0, ...s.users.map(u => u.id)) + 1;
  const user = {
    id, fullName: fullName.trim(), email: email.trim().toLowerCase(), phone: phone.trim(),
    password, referralCode: 'PRO-' + Math.floor(1000 + Math.random() * 9000),
    referredBy: referralCode || null, level: 1, xp: 100,
    availableBalance: 5000, activeInvestments: 0, pendingWithdrawal: 0,
    promotionalCredits: 250, loyaltyPoints: 100, isVerified: false, isAdmin: false,
    streakDays: 1, spinsToday: 1, createdAt: Date.now()
  };
  updateState(st => {
    st.users.push(user);
    st.notifications.push({
      id: Date.now(), userId: id, title: 'Welcome to PRO INVEST',
      message: 'Account created with ৳5,000 demo balance.', category: 'ANNOUNCEMENT', ts: Date.now(), read: false
    });
    st.sessionUserId = id;
  });
  return { ok: true, user };
}

function formatMoney(n) {
  return '৳' + Number(n || 0).toLocaleString('en-BD', { maximumFractionDigits: 0 });
}

function formatDate(ts) {
  return new Date(ts).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}
