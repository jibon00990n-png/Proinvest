/** Shared UI helpers */
function showLoader(msg) {
  hideLoader();
  const el = document.createElement('div');
  el.className = 'loader-overlay';
  el.id = 'globalLoader';
  el.innerHTML = `<div class="spinner"></div><div class="loader-text">${msg || 'Please wait…'}</div>`;
  document.body.appendChild(el);
}

function hideLoader() {
  const el = document.getElementById('globalLoader');
  if (el) el.remove();
}

function toast(message, type) {
  let box = document.querySelector('.toast-container');
  if (!box) {
    box = document.createElement('div');
    box.className = 'toast-container';
    document.body.appendChild(box);
  }
  const t = document.createElement('div');
  t.className = 'toast' + (type === 'error' ? ' error' : type === 'success' ? ' success' : '');
  t.textContent = message;
  box.appendChild(t);
  setTimeout(() => {
    t.style.opacity = '0';
    t.style.transition = '0.3s';
    setTimeout(() => t.remove(), 300);
  }, 2800);
}

async function withLoading(fn, msg) {
  showLoader(msg);
  await new Promise(r => setTimeout(r, 400));
  try {
    return await fn();
  } finally {
    hideLoader();
  }
}

function requireUser() {
  const u = getCurrentUser();
  if (!u || u.isAdmin) {
    window.location.href = '/login.html';
    return null;
  }
  return u;
}

function requireAdmin() {
  const u = getCurrentUser();
  if (!u || !u.isAdmin) {
    window.location.href = '/admin/login.html';
    return null;
  }
  return u;
}

function logout() {
  clearSession();
  window.location.href = '/login.html';
}

function adminLogout() {
  clearSession();
  window.location.href = '/admin/login.html';
}

function userNav(active) {
  const items = [
    { id: 'home', href: '/user/home.html', label: 'Home', icon: '🏠' },
    { id: 'plans', href: '/user/plans.html', label: 'Plans', icon: '📈' },
    { id: 'missions', href: '/user/missions.html', label: 'Missions', icon: '✅' },
    { id: 'spin', href: '/user/spin.html', label: 'Spin', icon: '🎰' },
    { id: 'profile', href: '/user/profile.html', label: 'Profile', icon: '👤' }
  ];
  return `<nav class="bottom-nav">${items.map(i => `
    <a class="nav-item ${active === i.id ? 'active' : ''}" href="${i.href}">
      <span style="font-size:18px">${i.icon}</span>${i.label}
    </a>`).join('')}</nav>`;
}

function userHeader(user, title) {
  const initial = (user.fullName || 'P').charAt(0).toUpperCase();
  return `
  <header class="header">
    <div class="header-inner">
      <div style="display:flex;align-items:center;gap:10px">
        <div class="avatar" onclick="location.href='/user/profile.html'">${initial}</div>
        <div>
          <div class="header-title">${title || 'PRO INVEST'}</div>
          <div class="header-sub">Lvl ${user.level} Investor ${user.isVerified ? '✓' : ''}</div>
        </div>
      </div>
      <a href="/user/notifications.html" style="position:relative;font-size:20px;text-decoration:none">
        🔔
      </a>
    </div>
  </header>`;
}
